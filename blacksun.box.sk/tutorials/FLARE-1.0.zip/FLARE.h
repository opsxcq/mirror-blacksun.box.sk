
/************************
FLARE.H - A C++ Win32 Multimedia Game Engine 

This source was coded by Raymond Jacobs. 
It is completely free of charge, and was 
written only to help people make better
and more reliable software soulutions.
            - Raymond (rmanpres@hotmail.com)
************************/

/************************
FLARE MESSAGE
************************/
#pragma message("Flare Version 1.0 �2002")
/************************
INCLUSION
************************/
#include <windows.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <string>
#include <limits.h>
using namespace std;			
/************************
DEFENITIONS
************************/
//Object Types
#define OBJECT_WINDOW					0x0
#define OBJECT_AUDIO					0x1
#define OBJECT_IMAGE					0x2
#define OBJECT_BUTTON					0x3
#define OBJECT_EDITBOX					0x4
#define OBJECT_SCROLLBAR				0x5
#define OBJECT_ACTOR2D					0x6
#define OBJECT_ACTOR3D					0x7
#define OBJECT_HOTSPOT					0x8
#define OBJECT_SPOTLIGHT				0x9
#define OBJECT_ZBUFFER					0xA
#define OBJECT_SYNCTIMER				0xB
#define OBJECT_SUBTITLE					0xC
#define OBJECT_IMAGEFONT				0xD
#define OBJECT_MOVIE					0xE
#define OBJECT_BLACKMAGIC				0xF
//Object Events
#define EVENT_AUDIO_START				0x0
#define EVENT_AUDIO_DONE				0x1
#define EVENT_AUDIO_EFFECT_REQ			0x2
#define EVENT_SCROLLBAR_DRAW			0x3
#define EVENT_ACTOR2D_DRAW_START		0x4
#define EVENT_ACTOR2D_DRAW_DONE			0x5
#define EVENT_ACTOR2D_ANIM_START		0x6
#define EVENT_ACTOR2D_ANIM_PULSE		0x7
#define EVENT_ACTOR2D_ANIM_DONE			0x8
#define EVENT_ACTOR2D_MOVE_START		0x9
#define EVENT_ACTOR2D_MOVE_PULSE		0xA
#define EVENT_ACTOR2D_MOVE_DONE			0xB
#define EVENT_ACTOR2D_HIT				0xC
#define EVENT_ACTOR3D_DRAW_START		0xD
#define EVENT_ACTOR3D_DRAW_DONE			0xE
#define EVENT_ACTOR3D_ANIM_START		0xF
#define EVENT_ACTOR3D_ANIM_PULSE		0x10
#define EVENT_ACTOR3D_ANIM_DONE			0x11
#define EVENT_ACTOR3D_MOVE_START		0x12
#define EVENT_ACTOR3D_MOVE_PULSE		0x13
#define EVENT_ACTOR3D_MOVE_DONE			0x14
#define EVENT_ACTOR3D_HIT				0x15
#define EVENT_HOTSPOT_HIT				0x16
#define EVENT_SPOTLIGHT_DRAW_START		0x17
#define EVENT_SPOTLIGHT_DRAW_DONE		0x18
#define EVENT_SPOTLIGHT_ANIM_START		0x19
#define EVENT_SPOTLIGHT_ANIM_PULSE		0x1A
#define EVENT_SPOTLIGHT_ANIM_DONE		0x1B
#define EVENT_SPOTLIGHT_MOVE_START		0x1C
#define EVENT_SPOTLIGHT_MOVE_PULSE		0x1D
#define EVENT_SPOTLIGHT_MOVE_DONE		0x1E
#define EVENT_SPOTLIGHT_HIT				0x1F
#define EVENT_ZBUFFER_DRAW_START		0x20
#define EVENT_ZBUFFER_DRAW_DONE			0x21
#define EVENT_ZBUFFER_DRAW_NODE_START	0x22
#define EVENT_ZBUFFER_DRAW_NODE_DONE	0x23
#define EVENT_ZBUFFER_HIT_START			0x24
#define EVENT_ZBUFFER_HIT_DONE			0x25
#define EVENT_ZBUFFER_HIT_NODE_START	0x26
#define EVENT_ZBUFFER_HIT_NODE_DONE		0x27
#define EVENT_ZBUFFER_GET_NODES			0x28
#define EVENT_SYNCTIMER_PERIOD_START	0x29
#define EVENT_SYNCTIMER_PERIOD_PULSE	0x2A
#define EVENT_SYNCTIMER_PERIOD_DONE		0x2B
#define EVENT_SUBTITLE_SHOW_START		0x2C
#define EVENT_SUBTITLE_SHOW_PULSE		0x2D
#define EVENT_SUBTITLE_SHOW_DONE		0x2E
#define EVENT_MOVIE_START				0x2F
#define EVENT_MOVIE_PULSE				0x30
#define EVENT_MOVIE_DONE				0x31
//Flags
#define COMPRESSION_NONE				0x0
#define COMPRESSION_COLOR				0x1
#define SECTOR_S						0x0
#define SECTOR_SW						0x1
#define SECTOR_W						0x2
#define SECTOR_NW						0x3
#define SECTOR_N						0x4
#define SECTOR_NE						0x5
#define SECTOR_E						0x6
#define SECTOR_SE						0x7
#define AUDIO_CHANS						0x64	//Digital Channels to Mix(100) Default
#define AUDIO_SLICE						0x8		//Division Factor for the blocks(8) Default
#define AUDIO_BLOCKS					0x3		//Number of wave blocks to use(2) Default
#define MOVIE_SEEK_BEGINING				0x0
#define MOVIE_SEEK_ARBITRARY			0x1
#define MOVIE_SEEK_END					0x2
#define LOOP_FOREVER					-1
#define IGNORE_PARAM					-1
#define MOTION_BLOCKS					0x1f4 //500
#define BLACKMAGIC_TYPE_RIVER			0x0
#define	RENDERMODE_POINT				0x0
#define	RENDERMODE_WIRE					0x1
#define	RENDERMODE_SOLID				0x2
#define	RENDERMODE_TEXTURE				0x3
#define	WORLD_FOCAL_LENGTH				1000
#define LIGHT_MAXBUFX					2000
#define LIGHT_MAXBUFY					2000
#define MAX_3D_FILE_LEN					0x1312D00
#define MAX_3D_TRIANGLES				30000
#define MAX_PATH_POINTS					0x7D0 //2000
#define MAX_SUBTITLE_ENTRIES			255
//3D Variables
float	PreCalcX1,PreCalcX2,PreCalcX3,PreCalcY1,PreCalcY2,PreCalcY3,PreCalcZ1,PreCalcZ2,PreCalcZ3;
float	PreCalcSin[256],PreCalcCos[256];                
bool	EngineInitiated=false;
//Light Variables
bool	LightPointDrawn[LIGHT_MAXBUFX*LIGHT_MAXBUFY];
//Callback type
typedef void	FP_Callback(unsigned char Event,unsigned char ObjectType,void *lpObjectPointer,unsigned char ExtendedType,void *lpExtendedPointer,const char *lpMessage);
struct FS_Color
{
	unsigned char B,G,R;
};
struct FS_ColorChunk
{
	FS_Color		ChunkColor;
	unsigned char	ChunkLength;
};
struct FS_WaveBlock
{
	WAVEHDR			BlockHeader;
	signed short	*lpBlockData;
};
struct FS_WaveSound
{
	WAVEFORMATEX	Format;
	unsigned long	Samples;
	signed char		*lpData;
	bool			Loaded;
};
struct FS_zNode
{
	signed long		zSortPoint;
	void			*lpObjectPointer;
	unsigned char	ObjectType;
};
struct FS_MotionBlock
{
	signed long				WalkX;
	signed long				WalkY;
	void					*lpNextBlock;

};
struct FS_Vector
{
	signed long x,y,z;
};
struct FS_Triangle
{
	FS_Vector Vector[3];
};
struct FS_Camera
{
	FS_Vector	ViewOrigin; 
	FS_Vector ViewRotation;
};
/************************
CLASS PRE-DEFENITION
************************/
class FC_Window;
class FC_Audio;
class FC_Image;
class FC_Button;
class FC_EditBox;
class FC_ScrollBar;
class FC_Actor2D;
class FC_Actor3D;
class FC_HotSpot;
class FC_SpotLight;
class FC_zBuffer;
class FC_SyncTimer;
class FC_SubTitle;
class FC_ImageFont;
class FC_Movie;
class FC_BlackMagic;
/************************
FUNCTION PRE-DEFENITION
************************/
bool				EvalMsg(string String,const char * lpString);
string				StrCmbRet(string String1,string String2);
long				GetRandNumber(long Lower,long Higher);
FS_Color			MakeColor(unsigned char R,unsigned char G,unsigned char B);
RECT				MakeDeviceRect(signed long Left,signed long Top,signed long Right,signed long Bottom);
RECT				MakeNormalRect(signed long Left,signed long Top,unsigned long Width,unsigned long Height);
RECT				GetScreenRect(void);
RECT				CenterRect(RECT OuterRect,RECT RectToCenter);
POINT				MakePoint(signed long Left,signed long Top);
void				ConvertLongToRGB(FS_Color *lpColor,unsigned long Color);
bool				CompareColor(FS_Color *lpColor1,FS_Color *lpColor2);
void				SortNodes(FS_zNode Nodes[],long start,long count,bool asc);
void				SetWindowsDisplayMode(unsigned long ScreenWidth,unsigned long ScreenHeight,unsigned char ColorDepth);
void				RestoreWindowsDisplayMode(void);
void				__forceinline WritePixel(signed long x,signed long y,FC_Image *lpImage,FS_Color *lpColor);
void				__forceinline ReadPixel(signed long x,signed long y,FC_Image *lpImage,FS_Color *lpColor);
void				__forceinline WritePixelAlpha(signed long x,signed long y,FC_Image *lpImage,FS_Color *lpColor,unsigned char Alpha);
bool				__forceinline WriteLine(long x1,long y1,long x2,long y2,FC_Image *lpImage,FS_Color *lpColor);
bool				 __forceinline WriteTextureLine(long x1,long y1,long x2,long y2,FC_Image *lpImage,FC_Image *lpTexture);
void				ImageTint(FC_Image *lpImage,bool RedOFF,bool GreenOFF,bool BlueOFF);
void				ImageFade(FC_Image *lpImage,FS_Color *lpColor,unsigned char Alpha);
unsigned long		ScanLinearPathSegment(POINT *lpPointArray,POINT Beg,POINT End);
bool				CheckVectorDirection(FC_Image *lpImage,POINT *lpOrigin,unsigned long RadialLength,unsigned char SectorIndex);
bool				CheckVectorDirectionToActors(FC_Actor2D *lpActors,const char *lpExcludeName,unsigned long NumActors,POINT *lpOrigin,unsigned long RadialLength,unsigned char SectorIndex);
signed char			GetVectorDirection(POINT PointA,POINT PointB);
long				SolveRelativeLong(long Ratio1Val,long Ratio1Max,long Ratio2Max,long OutputMin,long OutputMax);
float				SolveRelativeFloat(float Ratio1Val,float Ratio1Max,float Ratio2Max,float OutputMin,float OutputMax);
void				Initiate3DE(void);
FS_Vector			GetTrianglesCenter(FS_Triangle *lpTri,unsigned long NumberOfTriangles);
void				MoveTriangles(FS_Triangle *lpDest,FS_Triangle *lpSource,unsigned long NumTriangles,FS_Vector *lpMove,FS_Vector *lpOrigin);
void				RotateTriangles(FS_Triangle *lpDest,FS_Triangle *lpSource,unsigned long NumTriangles,FS_Vector *lpOrigin,FS_Vector *lpRotationVector);
void				DrawTriangles(FC_Image *lpImage,FC_Image *lpTexture,FS_Color *lpColor,FS_Triangle *lpTri,unsigned long NumTriangles,unsigned char RenderMethod);
void				SortTriangles(FS_Triangle Nodes[],long start,long count,bool asc);
void				ConvertRawToA3D(string File,float ScaleBy);
signed long			GetTrianglesCenterX(FS_Triangle *lpTri,unsigned long NumberOfTriangles);
signed long			GetTrianglesCenterY(FS_Triangle *lpTri,unsigned long NumberOfTriangles);
signed long			GetTrianglesCenterZ(FS_Triangle *lpTri,unsigned long NumberOfTriangles);
signed long			GetTrianglesLeft(FS_Triangle *lpTri,unsigned long NumberOfTriangles);
signed long			GetTrianglesTop(FS_Triangle *lpTri,unsigned long NumberOfTriangles);
signed long			GetTrianglesRight(FS_Triangle *lpTri,unsigned long NumberOfTriangles);
signed long			GetTrianglesBottom(FS_Triangle *lpTri,unsigned long NumberOfTriangles);
void				ScaleTriangles(FS_Triangle *lpDest,FS_Triangle *lpSource,unsigned long NumTriangles,float ScaleX,float ScaleY,float ScaleZ,FS_Vector *lpOrigin);
void CALLBACK		InternalProc1(HWAVEOUT hWaveOut,UINT Event,DWORD dwInstance,DWORD dwParam1,DWORD dwParam2);
LRESULT CALLBACK	InternalProc2(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam);
/************************
FLARE CLASSES
************************/
class FC_Window
{
	public:
		string		Name;
		MSG			msg;
		ATOM		hAtom;
		HWND		hWnd;
		HDC			ClientDC;
		HDC			WindowDC;
		WNDCLASS	WindowClass;
		RECT		Rect;
		void Window_Load(HINSTANCE hInstance,WNDPROC WindowProc,unsigned long ClassStyle,unsigned long WindowStyle,HICON hIcon,HCURSOR hCursor,HBRUSH hBrush,HWND hParent,HMENU hMenu,string MenuName,string ClassName,string Caption,RECT WindowRect,long nCmdShow)
		{
			Name=ClassName;
			WindowClass.style=ClassStyle;
			WindowClass.lpfnWndProc=WindowProc;
			WindowClass.hInstance=hInstance;
			WindowClass.hIcon=hIcon;
			WindowClass.hCursor=hCursor;
			WindowClass.hbrBackground=hBrush;
			WindowClass.lpszMenuName=MenuName.data();
			WindowClass.lpszClassName=ClassName.data();
			hAtom=RegisterClass(&WindowClass);
			CopyRect(&Rect,&WindowRect);
			hWnd=CreateWindow(Name.data(),Caption.data(),WindowStyle,WindowRect.left,WindowRect.top,WindowRect.right-WindowRect.left,WindowRect.bottom-WindowRect.top,hParent,hMenu,hInstance,0);    
			ClientDC=GetDC(hWnd);
			SetBkMode(ClientDC,TRANSPARENT);
			SetStretchBltMode(ClientDC,COLORONCOLOR);
			WindowDC=GetWindowDC(hWnd);
			ShowWindow(hWnd,nCmdShow);
			UpdateWindow(hWnd);
			return;
		}
		~FC_Window()
		{
			DestroyWindow(hWnd);
			UnregisterClass(Name.data(),WindowClass.hInstance);
			return;
		}
};
class FC_Audio
{
	private:
		HWAVEOUT		hWaveOut;
		FS_WaveBlock	WaveBlock[AUDIO_BLOCKS];
		unsigned long	WaveBlockSize;
		unsigned long	ChanNumInUse;
		unsigned long	ChanLen[AUDIO_CHANS];
		unsigned long	ChanPos[AUDIO_CHANS];
		unsigned long	ChanLoops[AUDIO_CHANS];
		unsigned long	ChanLoopCount[AUDIO_CHANS];
		signed short	*lpChanData[AUDIO_CHANS];
		bool			ChanActive[AUDIO_CHANS];
		bool			*lpChanDataValid[AUDIO_CHANS];
		string			ChanMessage[AUDIO_CHANS];
		unsigned char	CurrentBlock;
		bool			AudioEnabled;
		bool			AudioSilent;
		FP_Callback		*lpCallback;
	public:
		bool Audio_Initiate(FP_Callback *lpCallbackProcedure)
		{
			lpCallback=lpCallbackProcedure;
			if(!lpCallback)return false;
			WAVEFORMATEX	WaveFormatEx;
			unsigned char	i;
			WaveBlockSize=					(44100/AUDIO_SLICE)*2;		
			WaveFormatEx.wFormatTag=		WAVE_FORMAT_PCM;	//PCM 
			WaveFormatEx.nChannels=			1;					//Mono
			WaveFormatEx.nSamplesPerSec=	44100;
			WaveFormatEx.nAvgBytesPerSec=	44100*(44100/AUDIO_SLICE);
			WaveFormatEx.nBlockAlign=		44100/AUDIO_SLICE;
			WaveFormatEx.wBitsPerSample=	16;
			WaveFormatEx.cbSize=			NULL;
			waveOutOpen(&hWaveOut,WAVE_MAPPER,&WaveFormatEx,(DWORD)InternalProc1,(DWORD)this,(DWORD)CALLBACK_FUNCTION);
			// Allocate the buffers and clear the headers
			for(i=0;i<AUDIO_BLOCKS;i++)
			{
				WaveBlock[i].lpBlockData=(signed short*)GlobalAlloc(GPTR,WaveBlockSize);
				memset(WaveBlock[i].lpBlockData,SHRT_MIN,WaveBlockSize);
				memset(&WaveBlock[i].BlockHeader,NULL,sizeof(WAVEHDR));
			}
			//Cycle all buffers
			ChanNumInUse=NULL;
			CurrentBlock=NULL;
			AudioEnabled=true;
			AudioSilent=false;
			for(i=0;i<AUDIO_BLOCKS;i++)Audio_Pulse();
			return true;
		}
		void Audio_LoadSound(string File,FS_WaveSound *lpSound)
		{
			unsigned long	b; 
			long			lRet;
			MMCKINFO		CheckRIFF; 
			MMCKINFO		CheckTWO; 
			HMMIO			hMMIO;
			unsigned long	DataOffset;
			if(lpSound==NULL)return;
			memset(lpSound,NULL,sizeof(FS_WaveSound));   
			hMMIO=mmioOpen((char*)File.data(),NULL,MMIO_READ|MMIO_ALLOCBUF); 
			if(hMMIO==NULL)return; 
			CheckRIFF.fccType=mmioFOURCC('W','A','V','E'); 
			if(mmioDescend(hMMIO,&CheckRIFF,NULL,MMIO_FINDRIFF))return; 
			lpSound->Samples=(unsigned long)-1L; 
			while(MMSYSERR_NOERROR==mmioDescend(hMMIO,&CheckTWO,&CheckRIFF,0)) 
			{ 
				if((CheckTWO.dwDataOffset+CheckTWO.cksize)>(CheckRIFF.dwDataOffset+CheckRIFF.cksize))return;
				switch (CheckTWO.ckid) 
				{               
				case mmioFOURCC('f','m','t',' '): 
					b=CheckTWO.cksize; 
					if(b<sizeof(WAVEFORMATEX))
					{
						b=sizeof(WAVEFORMATEX); 
					}
					b=CheckTWO.cksize; 
					if(mmioRead(hMMIO,(HPSTR)&lpSound->Format,b)!=(LONG)b)return;
				case mmioFOURCC('d','a','t','a'): 
					DataOffset=CheckTWO.dwDataOffset; 
					break;
				case mmioFOURCC('f','a','c','t'):
					mmioRead(hMMIO,(HPSTR)&lpSound->Samples,sizeof(DWORD)); 
					break; 
				}
				mmioAscend(hMMIO,&CheckTWO,0); 
			} 
			//lpSound->Samples*=2; strange
			lpSound->lpData=(signed char*)GlobalAlloc(GPTR,lpSound->Samples*((lpSound->Format.wBitsPerSample/8)*lpSound->Format.nChannels));
			lRet=mmioSeek(hMMIO,DataOffset,SEEK_SET);
			lRet=mmioRead(hMMIO,(char*)lpSound->lpData,lpSound->Samples*((lpSound->Format.wBitsPerSample/8)*lpSound->Format.nChannels));
			if(hMMIO!=NULL)mmioClose(hMMIO,0); 
			lpSound->Loaded=true;
			return; 
		}
		void Audio_DestroySound(FS_WaveSound *lpSound)
		{
			if(lpSound->Loaded)
			{
				GlobalFree(lpSound->lpData);
				lpSound->Loaded=false;
				memset(lpSound,NULL,sizeof(FS_WaveSound));
			}
			return;
		}
		bool Audio_SetVolume2D(unsigned short LeftChannel,unsigned short RightChannel)
		{
			waveOutSetVolume(hWaveOut,MAKELONG(LeftChannel,RightChannel));
			return true;
		}
		bool Audio_SetVolume3D(unsigned long Width,unsigned long Height,signed long PanOrigin,signed long PanPosition)
		{
			signed long LeftChan=(PanPosition*0xFFFF)/(Width-PanOrigin);
			
			waveOutSetVolume(hWaveOut,MAKELONG(USHRT_MAX-LeftChan,LeftChan));
			return true;
		}
		bool Audio_Play(FS_WaveSound *lpSound,unsigned long Loops,string Message)
		{
			unsigned long i;
			Audio_Stop(Message,false);
			for(i=0;i<AUDIO_CHANS;i++)
			{
				if(!ChanActive[i])
				{
					ChanPos[i]=			NULL;
					ChanLen[i]=			lpSound->Samples;
					lpChanData[i]=		(signed short*)lpSound->lpData;
					ChanActive[i]=		true;
					lpChanDataValid[i]=	&lpSound->Loaded;
					ChanNumInUse++;
					ChanMessage[i]=		Message;
					ChanLoops[i]=		Loops;
					ChanLoopCount[i]=	NULL;
					lpCallback(EVENT_AUDIO_START,OBJECT_AUDIO,(void*)this,NULL,NULL,(const char*)Message.data());	
					return true;
				}
			}
			return false;
		}
		bool Audio_Stop(string Message,bool RelayMessage)
		{
			unsigned char i;
  			for(i=0;i<AUDIO_CHANS;i++)
			{
				if(!_stricmp(ChanMessage[i].data(),Message.data()))
				{
					ChanActive[i]=		NULL;
					ChanPos[i]=			NULL;
					ChanLen[i]=			NULL;
					lpChanData[i]=		NULL;				
					ChanMessage[i]=		"";
					ChanLoops[i]=		NULL;
					ChanLoopCount[i]=	NULL;
					ChanNumInUse--;
					if(RelayMessage)lpCallback(EVENT_AUDIO_DONE,OBJECT_AUDIO,(void*)this,NULL,NULL,Message.data());	
					return true;
				}
			}
			return false;
		}
		bool Audio_Flush(void)
		{
			unsigned char i;
			for(i=0;i<AUDIO_CHANS;i++)
			{
				if(ChanActive[i])
				{
					ChanNumInUse--;
					ChanActive[i]=		NULL;
					ChanPos[i]=			NULL;
					ChanLen[i]=			NULL;
					lpChanData[i]=		NULL;				
					ChanMessage[i]=		"";
					ChanLoops[i]=		NULL;
					ChanLoopCount[i]=	NULL;
				}
			}			
			return true;
		}
		void Audio_Pulse(void)
		{
			signed short	*lpData=(signed short*)WaveBlock[CurrentBlock].lpBlockData;
			signed long		FlowBuffer;
			unsigned long	Pos,Chan;
			if(WaveBlock[CurrentBlock].BlockHeader.dwFlags&WHDR_PREPARED)waveOutUnprepareHeader(hWaveOut,&WaveBlock[CurrentBlock].BlockHeader,sizeof(WAVEHDR));
			for(Pos=0;Pos<(WaveBlockSize/2);Pos++)
			{	
				FlowBuffer=SHRT_MIN;
				for(Chan=0;Chan<AUDIO_CHANS;Chan++)
				{
					if(ChanActive[Chan])
					{
						if(lpChanDataValid[Chan])
						{
							if(*lpChanDataValid[Chan])
							{
								if(!AudioSilent)FlowBuffer+=((lpChanData[Chan][ChanPos[Chan]]-SHRT_MIN)/ChanNumInUse);
								ChanPos[Chan]++;
								if(ChanPos[Chan]>ChanLen[Chan])
								{
									if(ChanLoops[Chan]!=LOOP_FOREVER)
									{
										if(ChanLoopCount[Chan]>=ChanLoops[Chan])
										{
											ChanNumInUse--;
											ChanActive[Chan]=		NULL;
											ChanPos[Chan]=			NULL;
											ChanLen[Chan]=			NULL;
											lpChanData[Chan]=		NULL;
											ChanLoops[Chan]=		NULL;
											ChanLoopCount[Chan]=	NULL;
											lpCallback(EVENT_AUDIO_DONE,OBJECT_AUDIO,(void*)this,NULL,NULL,ChanMessage[Chan].data());										
											ChanMessage[Chan]=		"";
										}
										else
										{
											ChanPos[Chan]=NULL;
											ChanLoopCount[Chan]++;
										}
									}
									else
									{
										ChanPos[Chan]=NULL;
									}
								}
							}
						}
					}
				}
				if(FlowBuffer>SHRT_MAX)FlowBuffer=SHRT_MAX;
				if(FlowBuffer<SHRT_MIN)FlowBuffer=SHRT_MIN;
				if(!AudioSilent)lpData[Pos]=FlowBuffer;
			}
			lpCallback(EVENT_AUDIO_EFFECT_REQ,OBJECT_AUDIO,(void*)this,NULL,(FS_WaveBlock*)&WaveBlock[CurrentBlock],"EFFECT_DATA_CODEC_REQUEST");
			WaveBlock[CurrentBlock].BlockHeader.lpData=(char*)WaveBlock[CurrentBlock].lpBlockData;
			WaveBlock[CurrentBlock].BlockHeader.dwBufferLength=WaveBlockSize;
			waveOutPrepareHeader(hWaveOut,&WaveBlock[CurrentBlock].BlockHeader,sizeof(WAVEHDR));
			waveOutWrite(hWaveOut,&WaveBlock[CurrentBlock].BlockHeader,sizeof(WAVEHDR));
			CurrentBlock++;
			if(CurrentBlock>=AUDIO_BLOCKS)CurrentBlock=NULL;
			return;
		}
		void Audio_SetAudioState(bool Silent)
		{
			AudioSilent=Silent;
			return;
		}
		bool Audio_GetAudioState(void)
		{
			return AudioSilent;
		}
		~FC_Audio()
		{
			if(AudioEnabled)
			{
				unsigned char	i;
				AudioSilent=true;
				waveOutReset(hWaveOut);
				for(i=0;i<AUDIO_BLOCKS;i++)
				{
					if(WaveBlock[i].BlockHeader.dwFlags&WHDR_PREPARED)waveOutUnprepareHeader(hWaveOut,&WaveBlock[i].BlockHeader,sizeof(WAVEHDR));
					GlobalFree(WaveBlock[i].lpBlockData);
				}
				waveOutClose(hWaveOut);
				AudioEnabled=false;
			}	
			return;
		}
};
class FC_Image
{
	private:
		HBITMAP				OldBM;
	public:
		bool				ImageInitilized;
		string				Name;
		HDC					ImageDC;
		HBITMAP				ImageBM;
		BITMAPINFO			ImageInfo;
		unsigned long		ImageWidth;
		unsigned long		ImageHeight;
		unsigned long		ImageSizePixels;
		unsigned long		ImageSizeBytes;
		FS_Color	*lpImagePixels;
		FC_Image()
		{
			ImageInitilized=false;
			return;
		}
		bool Image_Load(string File,unsigned long SetImageWidth,unsigned long SetImageHeight,bool LoadFile)
		{
			ImageInitilized=true;
			SelectObject(ImageDC,OldBM);
			if(ImageBM)DeleteObject(ImageBM);
			ImageBM=NULL;
			if(ImageDC)DeleteDC(ImageDC);
			ImageDC=NULL;
			lpImagePixels=NULL;
			ImageWidth=SetImageWidth;
			ImageHeight=SetImageHeight;
			FS_ColorChunk	*lpChunks;
			unsigned char CompressionType=0;
			unsigned long i,b,ImagePos=0,NumberOfChunks=0;;
			FILE	*lpFile;
			if(LoadFile)
			{
				lpFile=fopen(File.data(),"rb");
				if(!lpFile)return false;
				fseek(lpFile,NULL,SEEK_SET);//Set position to 0
				fread(&CompressionType,sizeof(CompressionType),1,lpFile);
				fread(&ImageWidth,sizeof(ImageWidth),1,lpFile);
				fread(&ImageHeight,sizeof(ImageHeight),1,lpFile);
				ImageDC=CreateCompatibleDC(NULL);
				SetTextColor(ImageDC,0xFF);
				SetBkMode(ImageDC,TRANSPARENT);
				SetStretchBltMode(ImageDC,COLORONCOLOR);
				memset(&ImageInfo,0,sizeof(BITMAPINFO));
				ImageInfo.bmiHeader.biSize=sizeof(BITMAPINFOHEADER); 
				ImageInfo.bmiHeader.biWidth=		ImageWidth; 
				ImageInfo.bmiHeader.biHeight=		(-ImageHeight);
				ImageInfo.bmiHeader.biPlanes=		1; 
				ImageInfo.bmiHeader.biBitCount=		24;
				ImageInfo.bmiHeader.biCompression=	BI_RGB;
				ImageInfo.bmiHeader.biSizeImage=	0; 
				ImageBM=CreateDIBSection(ImageDC,&ImageInfo,DIB_RGB_COLORS,(void**)&lpImagePixels,NULL,NULL); 
				SelectObject(ImageDC,ImageBM);
				switch(CompressionType)
				{
				case COMPRESSION_NONE://Logical RGB stream
					fread(lpImagePixels,ImageWidth*ImageHeight*sizeof(FS_Color),1,lpFile);
					break;
				case COMPRESSION_COLOR://Run Length encoded
					fread(&NumberOfChunks,sizeof(NumberOfChunks),1,lpFile);
					lpChunks=(FS_ColorChunk*)GlobalAlloc(GPTR,NumberOfChunks*sizeof(FS_ColorChunk));
					fread(&lpChunks[0],NumberOfChunks*sizeof(FS_ColorChunk),1,lpFile);
					for(i=0;i<NumberOfChunks;i++)
					{
						for(b=0;b<lpChunks[i].ChunkLength;b++)
						{
							memcpy(&lpImagePixels[ImagePos],&lpChunks[i].ChunkColor,sizeof(FS_Color));
							ImagePos++;
						}
					}	
					GlobalFree(lpChunks);
					break;
				default:
					break;
				}
				fclose(lpFile);	
			}
			else
			{
				ImageDC=CreateCompatibleDC(NULL);
				SetTextColor(ImageDC,0xFF);
				SetBkMode(ImageDC,TRANSPARENT);
				SetStretchBltMode(ImageDC,COLORONCOLOR);
				memset(&ImageInfo,0,sizeof(BITMAPINFO));
				ImageInfo.bmiHeader.biSize=sizeof(BITMAPINFOHEADER); 
				ImageInfo.bmiHeader.biWidth=		ImageWidth; 
				ImageInfo.bmiHeader.biHeight=		-ImageHeight;
				ImageInfo.bmiHeader.biPlanes=		1; 
				ImageInfo.bmiHeader.biBitCount=		24;
				ImageInfo.bmiHeader.biCompression=	BI_RGB;
				ImageInfo.bmiHeader.biSizeImage=	0; 
				ImageBM=CreateDIBSection(ImageDC,&ImageInfo,DIB_RGB_COLORS,(void**)&lpImagePixels,NULL,0); 
				OldBM=(HBITMAP)SelectObject(ImageDC,ImageBM);
			}
			ImageSizePixels=ImageWidth*ImageHeight;
			ImageSizeBytes=ImageWidth*ImageHeight*3;
			return true;
		}
		bool Image_Save(string File,unsigned char CompressionType)
		{	
			FILE*					lpFile;
			FS_ColorChunk	*lpChunks;
			FS_Color		TempColor;
			unsigned long			i,ChunkPos=0;
			lpFile=fopen(File.data(),"wb");
			if(!lpFile)return false;
			fseek(lpFile,NULL,SEEK_SET);
			switch(CompressionType)
			{
			case COMPRESSION_NONE:
				fwrite(&CompressionType,sizeof(CompressionType),1,lpFile);
				fwrite(&ImageWidth,sizeof(ImageWidth),1,lpFile);
				fwrite(&ImageHeight,sizeof(ImageHeight),1,lpFile);
				fwrite(&lpImagePixels[0],ImageWidth*ImageHeight*sizeof(FS_Color),1,lpFile);
				break;
			case COMPRESSION_COLOR:
				fwrite(&CompressionType,sizeof(CompressionType),1,lpFile);
				fwrite(&ImageWidth,sizeof(ImageWidth),1,lpFile);
				fwrite(&ImageHeight,sizeof(ImageHeight),1,lpFile);
				
				memcpy(&TempColor,&lpImagePixels[0],sizeof(FS_Color));
				//Copy the first color in the Image to the first chunk
				lpChunks=(FS_ColorChunk*)GlobalAlloc(GPTR,ImageSizePixels*sizeof(FS_ColorChunk));
				memcpy(&lpChunks[0].ChunkColor,&lpImagePixels[0],sizeof(FS_Color));
				lpChunks[0].ChunkLength=1;
				//Search the rest of the map for colors
				for(i=1;i<ImageSizePixels;i++)
				{
					if(CompareColor(&TempColor,&lpImagePixels[i])&&lpChunks[ChunkPos].ChunkLength<255)
					{
						//Color is the same and we wont overflow to just increment the length on the current chunk
						lpChunks[ChunkPos].ChunkLength++;
					}
					else
					{
						//The color was not the same, or we have reached a length of 255
						ChunkPos++;//use the next chunk in line
						memcpy(&lpChunks[ChunkPos].ChunkColor,&lpImagePixels[i],sizeof(FS_Color));
						lpChunks[ChunkPos].ChunkLength=1;
						memcpy(&TempColor,&lpChunks[ChunkPos].ChunkColor,sizeof(FS_Color));
					}
				}
				ChunkPos++;
				fwrite(&ChunkPos,sizeof(ChunkPos),1,lpFile);
				fwrite(lpChunks,ChunkPos*sizeof(FS_ColorChunk),1,lpFile);
				GlobalFree(lpChunks);
				break;
			}
			fclose(lpFile);
			return true;
		}
		~FC_Image()
		{
			if(!ImageInitilized)return;
			SelectObject(ImageDC,OldBM);
			if(ImageBM)DeleteObject(ImageBM);
			ImageBM=NULL;
			if(ImageDC)DeleteDC(ImageDC);
			ImageDC=NULL;
			lpImagePixels=NULL;
			ImageInitilized=false;
			return;
		}
};
class FC_Button
{
	public:
		HWND				ButtonWnd;
		WORD				ButtonID;
		string				Name;
		FC_Button()
		{
			return;
		}
		bool Button_Load(string SetName,unsigned long ButtonStyle,FC_Window *lpParentWnd,RECT ButtonPosition,WORD ButtonID)
		{
			Name=SetName;
			ButtonWnd=CreateWindow("BUTTON",Name.data(),WS_CHILD|ButtonStyle,ButtonPosition.left,ButtonPosition.top,ButtonPosition.right-ButtonPosition.left,ButtonPosition.bottom-ButtonPosition.top,lpParentWnd->hWnd,NULL,NULL,NULL);
			SetWindowLong(ButtonWnd,GWL_ID,ButtonID);
			if(!ButtonWnd)return false;
			//SetWindowLong(ButtonWnd,GWL_WNDPROC,(LONG)ControlProc);
			ShowWindow(ButtonWnd,SW_NORMAL);
			return true;
		}
		string Button_GetCaption(void)
		{
			string TempString;
			TempString.resize(500);
			TempString.resize(GetWindowText(ButtonWnd,(char*)TempString.data(),500));
			return TempString;
		}
		void Button_SetCaption(string SetCaption)
		{
			SetWindowText(ButtonWnd,SetCaption.data());
			return;
		}
		~FC_Button()
		{
			DestroyWindow(ButtonWnd);
			return;
		}
};
class FC_EditBox
{
	public:
		HWND				EditWnd;
		WORD				EditID;
		string				Name;
		FC_EditBox()
		{
			return;
		}
		bool EditBox_Load(string SetName,unsigned long EditStyle,FC_Window *lpParentWnd,RECT EditPosition,WORD EditID)
		{
			Name=SetName;
			EditWnd=CreateWindow("EDIT",Name.data(),WS_CHILD|EditStyle,EditPosition.left,EditPosition.top,EditPosition.right-EditPosition.left,EditPosition.bottom-EditPosition.top,lpParentWnd->hWnd,NULL,NULL,NULL);
			if(!EditWnd)return false;
			SetWindowLong(EditWnd,GWL_ID,EditID);
			ShowWindow(EditWnd,SW_NORMAL);
			return true;
		}
		string EditBox_GetCaption(void)
		{
			string TempString;
			TempString.resize(500);
			TempString.resize(GetWindowText(EditWnd,(char*)TempString.data(),500));
			return TempString;
		}
		void EditBox_SetCaption(string SetCaption)
		{
			SetWindowText(EditWnd,SetCaption.data());
			return;
		}
		~FC_EditBox()
		{
			DestroyWindow(EditWnd);
			return;
		}
};
class FC_ScrollBar
{
	private:
		bool				Visible;
	public:
		bool				UseEvents;
		bool				HasFocus;
		bool				Vertical;
		bool				OwnerDraw;
		HWND				ScrollBarWnd;
		string				Name;
		float				Min;
		float				Max;
		float				Value;
		RECT				Rect;
		RECT				WindowRect;
		FC_Image	Buffer;
		FP_Callback	*lpCallback;
		FC_ScrollBar()
		{
			WNDCLASS WndClass;
			WndClass.cbClsExtra=	NULL;
			WndClass.cbWndExtra=	NULL;
			WndClass.hbrBackground=	(HBRUSH)GetStockObject(BLACK_BRUSH);
			WndClass.hCursor=		LoadCursor(NULL,IDC_ARROW);
			WndClass.hIcon=			NULL;
			WndClass.hInstance=		NULL;
			WndClass.lpfnWndProc=	InternalProc2;
			WndClass.lpszClassName=	"FlareControl_ScrollBar";
			WndClass.lpszMenuName=	"";
			WndClass.style=			CS_NOCLOSE|CS_HREDRAW|CS_VREDRAW;
			RegisterClass(&WndClass);
			Visible=false;
			Vertical=true;
			lpCallback=NULL;
			UseEvents=true;
			OwnerDraw=false;
			return;
		}
		bool ScrollBar_Load(string SetName,bool IsVertical,HWND hParent,RECT ScrollBarPosition,float SetMin,float SetMax,FP_Callback *lpCallbackProcedure)
		{
			if(!lpCallbackProcedure)UseEvents=false;
			lpCallback=lpCallbackProcedure;
			unsigned long Width=ScrollBarPosition.right-ScrollBarPosition.left;
			unsigned long Height=ScrollBarPosition.bottom-ScrollBarPosition.top;
			Name=SetName;
			Min=SetMin;
			Max=SetMax;
			Vertical=IsVertical;
			Buffer.Image_Load(Name,Width,Height,false);
			ScrollBarWnd=CreateWindow("FlareControl_ScrollBar",Name.data(),WS_CHILD,ScrollBarPosition.left,ScrollBarPosition.top,ScrollBarPosition.right-ScrollBarPosition.left,ScrollBarPosition.bottom-ScrollBarPosition.top,hParent,NULL,NULL,NULL);
			if(!ScrollBarWnd)return false;
			SetWindowLong(ScrollBarWnd,GWL_USERDATA,(LONG)this);
			CopyRect(&WindowRect,&ScrollBarPosition);
			Rect=MakeNormalRect(NULL,NULL,Width,Height);
			return true;
		}
		void ScrollBar_SetValue(float SetValue)
		{
			Value=SetValue;
			InvalidateRect(ScrollBarWnd,NULL,false);
			return;
		}
		float ScrollBar_GetValue(void)
		{
			return Value;
		}
		void ScrollBar_SetVisible(bool SetVisible)
		{
			Visible=SetVisible;
			if(SetVisible)
			{
				ShowWindow(ScrollBarWnd,SW_NORMAL);
			}
			else
			{
				ShowWindow(ScrollBarWnd,SW_HIDE);

			}
		}
		bool ScrollBar_GetVisible(void)
		{
			return Visible;
		}
		~FC_ScrollBar()
		{
			DestroyWindow(ScrollBarWnd);
			return;
		}
};
class FC_Actor2D
{
	private:
		bool					Actor2DInitilized;
		FP_Callback		*lpCallback;
		FC_Image		HitMask;
		unsigned long			CellWidth;
		unsigned long			CellHeight;
		unsigned long			MaxFrames;
		unsigned long			MaxTracks;
		unsigned long			SourceROP;
		unsigned long			MaskROP;
		bool					UseMask;
		bool					UseEvents;
		unsigned long			AnimFrames;
		unsigned long			AnimRetFrame;
		unsigned long			AnimRetTrack;
		unsigned long			AnimTrack;
		unsigned long			AnimLoops;
		unsigned long			AnimLoopCounter;
		unsigned long			AnimIntervalCounter;
		POINT					MotionPath[MAX_PATH_POINTS];
		unsigned long			MotionNumPathPoints;
		float					MotionCurrentPathPoint;
		bool					MotionNoStartMsg;
	public:
		FS_MotionBlock			*lpMotionBlock;
		string					Name;
		string					AnimMessage;
		string					MotionMessage;
		FC_Image				*lpSource;
		FC_Image				*lpMask;
		signed long				Left;
		signed long				Top;
		unsigned long			SourceID;
		unsigned long			MaskID;
		unsigned long			CurrentFrame;
		unsigned long			CurrentTrack;
		unsigned long			OutputWidth;
		unsigned long			OutputHeight;
		unsigned long			AnimationInterval;
		bool					Visible;
		bool					Clickable;
		bool					Animating;
		bool					Moving;
		POINT					zSortPoint;
		unsigned long			UserStructSize;
		void					*lpUserStruct;
		float					MotionStepRate;
		FS_MotionBlock			MotionBlock[MOTION_BLOCKS];
		FC_Actor2D()
		{
			Actor2DInitilized=		false;
			Name=					"";
			SourceID=				NULL;
			MaskID=					NULL;
			lpCallback=				NULL;
			lpSource=				NULL;
			lpMask=					NULL;
			CellWidth=				NULL;
			CellHeight=				NULL;
			MaxFrames=				NULL;
			MaxTracks=				NULL;
			SourceROP=				SRCPAINT;
			MaskROP=				SRCAND;
			UseMask=				true;
			UseEvents=				true;
			AnimFrames=				NULL;
			AnimRetFrame=			NULL;
			AnimRetTrack=			NULL;
			AnimTrack=				NULL;
			AnimLoops=				NULL;
			AnimLoopCounter=		NULL;
			AnimIntervalCounter=	NULL;
			AnimMessage=			"";
			lpMotionBlock=			NULL;
			MotionNumPathPoints=	NULL;
			MotionCurrentPathPoint=	NULL;
			MotionNoStartMsg=		false;
			MotionStepRate=			NULL;
			MotionMessage=			"";
			Left=					NULL;
			Top=					NULL;
			CurrentFrame=			NULL;
			CurrentTrack=			NULL;
			OutputWidth=			NULL;
			OutputHeight=			NULL;
			AnimationInterval=		NULL;
			Visible=				false;
			Clickable=				true;
			Animating=				false;
			Moving=					false;
			UserStructSize=			NULL;
			lpUserStruct=			NULL;
			return;
		}
		bool Actor2D_Load(string SetName,FC_Image *lpSourceImage,FC_Image *lpMaskImage,unsigned long HitMaskWidth,unsigned long HitMaskHeight,unsigned long SetUserStructSize,FP_Callback *lpCallbackProcedure)
		{
			Name=SetName;
			if(!lpCallbackProcedure)UseEvents=false;
			lpCallback=lpCallbackProcedure;
			
			if(!lpSourceImage)return false;
			lpSource=lpSourceImage;	
			
			if(!lpMaskImage)
			{
				UseMask=	false;
				SourceROP=	SRCCOPY;
				MaskROP=	NULL;
			}
			lpMask=lpMaskImage;	
			HitMask.~FC_Image();
			if(UseMask)HitMask.Image_Load(lpSource->Name+"HitMask",HitMaskWidth,HitMaskHeight,false);
			UserStructSize=SetUserStructSize;
			if(!lpUserStruct)
			{
				lpUserStruct=(void*)GlobalAlloc(GPTR,UserStructSize);
				Actor2DInitilized=true;
			}
			return true;
		}
		bool Actor2D_Pose(signed long SetLeft,signed long SetTop,unsigned long SetMaxFrames,unsigned long SetMaxTracks,unsigned long SetCurrentFrame,unsigned long SetCurrentTrack,unsigned long SetOutputWidth,unsigned long SetOutputHeight,bool SetClickable,bool SetVisible)
		{
			if(!Actor2DInitilized)return false;
			Actor2D_StopAnimating(false);
			Actor2D_StopMoving(false);
			Left=SetLeft;
			Top=SetTop;
			MaxFrames=SetMaxFrames;
			MaxTracks=SetMaxTracks;
			if(!MaxFrames||!MaxTracks)return false;
			CellWidth=(lpSource->ImageWidth/MaxFrames);
			CellHeight=(lpSource->ImageHeight/MaxTracks);
			CurrentFrame=SetCurrentFrame;
			CurrentTrack=SetCurrentTrack;
			OutputWidth=SetOutputWidth;
			OutputHeight=SetOutputHeight;
			Clickable=SetClickable;
			Visible=SetVisible;
			zSortPoint.x=Left+(OutputWidth/2);
			zSortPoint.y=Top+(OutputHeight*.75);
			return true;
		}
		bool Actor2D_Draw(FC_Image *lpImage)
		{
			if(!Actor2DInitilized||!Visible)return false;
			zSortPoint.x=Left+(OutputWidth/2);
			zSortPoint.y=Top+(OutputHeight*.75);
			if(UseEvents)lpCallback(EVENT_ACTOR2D_DRAW_START,OBJECT_ACTOR2D,this,NULL,NULL,"");
			if(UseMask)
			{
				StretchBlt(HitMask.ImageDC,NULL,NULL,OutputWidth,OutputHeight,lpMask->ImageDC,CurrentFrame*CellWidth,CurrentTrack*CellHeight,CellWidth,CellHeight,SRCCOPY);
				StretchBlt(lpImage->ImageDC,Left,Top,OutputWidth,OutputHeight,lpMask->ImageDC,CurrentFrame*CellWidth,CurrentTrack*CellHeight,CellWidth,CellHeight,MaskROP);
			}
			StretchBlt(lpImage->ImageDC,Left,Top,OutputWidth,OutputHeight,lpSource->ImageDC,CurrentFrame*CellWidth,CurrentTrack*CellHeight,CellWidth,CellHeight,SourceROP);
			if(UseEvents)lpCallback(EVENT_ACTOR2D_DRAW_DONE,OBJECT_ACTOR2D,this,NULL,NULL,"");
			if(Animating)
			{
				if(AnimIntervalCounter>=AnimationInterval)
				{
					AnimIntervalCounter=NULL;
					if(CurrentFrame>=(AnimFrames-1))
					{	
						CurrentFrame=NULL;
						if(AnimLoops!=LOOP_FOREVER)
						{
							if(AnimLoopCounter>=AnimLoops)
							{
								Actor2D_StopAnimating(true);
								if(UseEvents)lpCallback(EVENT_ACTOR2D_ANIM_DONE,OBJECT_ACTOR2D,this,NULL,NULL,AnimMessage.data());
							}
							else
							{
								AnimLoopCounter++;
							}
						}
					}
					else
					{
						CurrentFrame++;
						if(UseEvents)lpCallback(EVENT_ACTOR2D_ANIM_PULSE,OBJECT_ACTOR2D,this,NULL,NULL,AnimMessage.data());
					}
				}
				else
				{
					AnimIntervalCounter++;
				}
			}
			if(Moving)
			{
				if(UseEvents)lpCallback(EVENT_ACTOR2D_MOVE_PULSE,OBJECT_ACTOR2D,this,NULL,NULL,MotionMessage.data());
				if(!Moving)return true;
				Left=(MotionPath[(unsigned long)MotionCurrentPathPoint].x-abs(zSortPoint.x-Left));
				Top=(MotionPath[(unsigned long)MotionCurrentPathPoint].y-abs(zSortPoint.y-Top));
				MotionCurrentPathPoint+=MotionStepRate;
				if(MotionCurrentPathPoint>MotionNumPathPoints)
				{
					if(lpMotionBlock->lpNextBlock)
					{
						MotionNoStartMsg=true;
						Actor2D_StartMoving(true,MotionStepRate,(FS_MotionBlock*)lpMotionBlock->lpNextBlock,MotionMessage);
						MotionNoStartMsg=false;
					}
					else
					{
						Actor2D_StopMoving(true);
					}
				}
			}
			return true;
		}
		bool Actor2D_StartAnimating(bool Interupt,unsigned long SetStartFrame,unsigned long SetEndFrame,unsigned long SetAnimLoops,unsigned long SetAnimTrack,unsigned long SetReturnFrame,unsigned long SetReturnTrack,unsigned long SetAnimInterval,string SetAnimMessage)
		{
			zSortPoint.x=Left+(OutputWidth/2);
			zSortPoint.y=Top+(OutputHeight*.75);
			if(!Actor2DInitilized)return false;
			if(Animating&&!Interupt)return false;
			if(Animating&&Interupt)Actor2D_StopAnimating(false);
			AnimFrames=SetEndFrame;
			AnimLoops=SetAnimLoops;
			AnimTrack=SetAnimTrack;
			AnimRetFrame=SetReturnFrame;
			AnimRetTrack=SetReturnTrack;
			AnimationInterval=SetAnimInterval;
			AnimMessage=SetAnimMessage;
			CurrentFrame=SetStartFrame;
			CurrentTrack=SetAnimTrack;
			Animating=true;
			if(UseEvents)lpCallback(EVENT_ACTOR2D_ANIM_START,OBJECT_ACTOR2D,this,NULL,NULL,AnimMessage.data());
			return true;
		}
		bool Actor2D_StopAnimating(bool RelayMessage)
		{
			if(!Actor2DInitilized&&!Animating)return false;
			string TempMsg=AnimMessage;
			Animating=false;
			if(AnimRetFrame!=IGNORE_PARAM)CurrentFrame=AnimRetFrame;
			if(AnimRetTrack!=IGNORE_PARAM)CurrentTrack=AnimRetTrack;
			AnimIntervalCounter=NULL;
			AnimFrames=NULL;
			AnimLoops=NULL;
			AnimTrack=NULL;
			if(UseEvents&&RelayMessage)lpCallback(EVENT_ACTOR2D_ANIM_DONE,OBJECT_ACTOR2D,this,NULL,NULL,AnimMessage.data());
			if(EvalMsg(TempMsg,AnimMessage.data()))AnimMessage="";
			return true;
		}
		void Actor2D_PrepareMotionBlock(unsigned long BlockIndex,signed long WalkX, signed long WalkY,FS_MotionBlock *lpNextBlock)
		{
			MotionBlock[BlockIndex].WalkX=WalkX;
			MotionBlock[BlockIndex].WalkY=WalkY;
			MotionBlock[BlockIndex].lpNextBlock=lpNextBlock;
			return;
		}
		bool Actor2D_StartMoving(bool Interupt,float SetStepRate,FS_MotionBlock *lpMBlock,string SetMotionMessage)
		{
			zSortPoint.x=Left+(OutputWidth/2);
			zSortPoint.y=Top+(OutputHeight*.75);
			if(!lpMBlock)return false;
			if(Moving&&!Interupt)return false;
			MotionMessage=SetMotionMessage;
			MotionStepRate=SetStepRate;
			lpMotionBlock=lpMBlock;
			MotionNumPathPoints=ScanLinearPathSegment(&MotionPath[0],MakePoint(zSortPoint.x,zSortPoint.y),MakePoint(lpMotionBlock->WalkX,lpMotionBlock->WalkY));
			MotionCurrentPathPoint=NULL;
			Moving=true;
			if(!MotionNoStartMsg)if(UseEvents)lpCallback(EVENT_ACTOR2D_MOVE_START,OBJECT_ACTOR2D,this,NULL,NULL,MotionMessage.data());
			return true;
		}
		bool Actor2D_StopMoving(bool RelayMessage)
		{
			string TempMsg=MotionMessage;
			Moving=false;
			if(UseEvents&&RelayMessage)lpCallback(EVENT_ACTOR2D_MOVE_DONE,OBJECT_ACTOR2D,this,NULL,NULL,MotionMessage.data());
			if(EvalMsg(TempMsg,MotionMessage.data()))MotionMessage="";
			return true;
		}
		POINT Actor2D_GetCurrentMotionPoint(void)
		{
			return MotionPath[(unsigned long)MotionCurrentPathPoint];
		}
		POINT Actor2D_GetFinalMotionPoint(void)
		{
			return MotionPath[(unsigned long)MotionNumPathPoints];
		}
		bool Actor2D_HitTestPoint(POINT *lpPoint,string Message)
		{
			if(Visible&&Clickable&&(lpPoint->x>=Left)&&(lpPoint->x<=(Left+OutputWidth))&&(lpPoint->y>=Top)&&(lpPoint->y<=(Top+OutputHeight)))
			{
				if(UseMask)
				{
					if(GetPixel(HitMask.ImageDC,labs(lpPoint->x-Left),labs(lpPoint->y-Top))!=0xFFFFFF)
					{
							if(UseEvents)lpCallback(EVENT_ACTOR2D_HIT,OBJECT_ACTOR2D,(void*)this,NULL,NULL,Message.data());
							return true;
					}
				}
				else
				{
					return true;
				}
			}
			return false;
		}
		bool Actor2D_SaveState(string GameFile,string SectorName)
		{
			if(Moving)return false;
			WritePrivateProfileString(SectorName.data(),"ACTOR2D_A",Name.data(),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_B",&SourceID,sizeof(SourceID),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_B",&MaskID,sizeof(MaskID),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_B",&CellWidth,sizeof(CellWidth),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_C",&CellHeight,sizeof(CellHeight),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_D",&MaxFrames,sizeof(MaxFrames),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_E",&MaxTracks,sizeof(MaxTracks),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_F",&SourceROP,sizeof(SourceROP),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_G",&MaskROP,sizeof(MaskROP),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_H",&AnimFrames,sizeof(AnimFrames),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_I",&AnimRetFrame,sizeof(AnimRetFrame),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_J",&AnimRetTrack,sizeof(AnimRetTrack),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_K",&AnimTrack,sizeof(AnimTrack),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_L",&AnimLoops,sizeof(AnimLoops),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_M",&AnimLoopCounter,sizeof(AnimLoopCounter),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_N",&AnimIntervalCounter,sizeof(AnimIntervalCounter),GameFile.data());
			WritePrivateProfileString(SectorName.data(),"ACTOR2D_O",AnimMessage.data(),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_P",&Left,sizeof(Left),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_Q",&Top,sizeof(Top),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_R",&CurrentFrame,sizeof(CurrentFrame),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_S",&CurrentTrack,sizeof(CurrentTrack),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_T",&OutputWidth,sizeof(OutputWidth),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_U",&OutputHeight,sizeof(OutputHeight),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_V",&AnimationInterval,sizeof(AnimationInterval),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_W",&Visible,sizeof(Visible),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_X",&Clickable,sizeof(Clickable),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_Y",&Animating,sizeof(Animating),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_USERSTRUCTSIZE",&UserStructSize,sizeof(UserStructSize),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"ACTOR2D_USERSTRUCT",lpUserStruct,UserStructSize,GameFile.data());
			return true;
		}		
		bool Actor2D_LoadState(string GameFile,string SectorName)
		{
			if(Moving)return false;
			Name.resize(255);
			AnimMessage.resize(255);
			GetPrivateProfileString(SectorName.data(),"ACTOR2D_A","",(char*)Name.data(),255,GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_B",&SourceID,sizeof(SourceID),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_B",&MaskID,sizeof(MaskID),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_B",&CellWidth,sizeof(CellWidth),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_C",&CellHeight,sizeof(CellHeight),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_D",&MaxFrames,sizeof(MaxFrames),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_E",&MaxTracks,sizeof(MaxTracks),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_F",&SourceROP,sizeof(SourceROP),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_G",&MaskROP,sizeof(MaskROP),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_H",&AnimFrames,sizeof(AnimFrames),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_I",&AnimRetFrame,sizeof(AnimRetFrame),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_J",&AnimRetTrack,sizeof(AnimRetTrack),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_K",&AnimTrack,sizeof(AnimTrack),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_L",&AnimLoops,sizeof(AnimLoops),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_M",&AnimLoopCounter,sizeof(AnimLoopCounter),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_N",&AnimIntervalCounter,sizeof(AnimIntervalCounter),GameFile.data());
			GetPrivateProfileString(SectorName.data(),"ACTOR2D_O","",(char*)AnimMessage.data(),255,GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_P",&Left,sizeof(Left),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_Q",&Top,sizeof(Top),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_R",&CurrentFrame,sizeof(CurrentFrame),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_S",&CurrentTrack,sizeof(CurrentTrack),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_T",&OutputWidth,sizeof(OutputWidth),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_U",&OutputHeight,sizeof(OutputHeight),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_V",&AnimationInterval,sizeof(AnimationInterval),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_W",&Visible,sizeof(Visible),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_X",&Clickable,sizeof(Clickable),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_Y",&Animating,sizeof(Animating),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_USERSTRUCTSIZE",&UserStructSize,sizeof(UserStructSize),GameFile.data());
			lpUserStruct=(void*)GlobalReAlloc(lpUserStruct,UserStructSize,GMEM_ZEROINIT);
			GetPrivateProfileStruct(SectorName.data(),"ACTOR2D_USERSTRUCT",lpUserStruct,UserStructSize,GameFile.data());
			return true;
		}

		~FC_Actor2D()
		{
			lpSource=NULL;
			lpMask=NULL;
			if(lpUserStruct)GlobalFree(lpUserStruct);
			lpUserStruct=NULL;
			Actor2DInitilized=false;
			return;
		}
};
class FC_Actor3D
{
	public:
		bool			Actor3DInitilized;
		bool			UseEvents;
		string			Name;
		FP_Callback		*lpCallback;
		unsigned long	NumberOfTriangles;
		FS_Triangle	*lpTriangles;
		FS_Triangle	*lpTempTriangles;
		FS_Camera		*lpCamera;
		FC_Image		*lpRenderTexture;
		FS_Vector		Position;
		FS_Vector		Rotation;//Use only ubyte values
		FS_Vector		RotationOriginOffset;
		FS_Color		RenderColor;
		unsigned char	RenderMode;
		POINT			zSortPoint;
		POINT			MotionPath[MAX_PATH_POINTS];
		unsigned long	MotionNumPathPoints;
		float			MotionCurrentPathPoint;
		bool			MotionNoStartMsg;
		string			MotionMessage;
		string			AnimMessage;
		float			MotionStepRate;
		FS_MotionBlock	MotionBlock[MOTION_BLOCKS];
		FS_MotionBlock	*lpMotionBlock;
		signed long		xRotEnd;
		float			xRotInc;
		bool			xRotAnim;
		signed long		yRotEnd;
		float			yRotInc;
		bool			yRotAnim;
		signed long		zRotEnd;
		float			zRotInc;
		bool			zRotAnim;
		float			xRotTemp;
		float			yRotTemp;
		float			zRotTemp;
		bool			xIncIsNeg;
		bool			yIncIsNeg;
		bool			zIncIsNeg;
		bool			Moving;
		bool			Animating;
		bool			Clickable;
		bool			Visible;
		FC_Actor3D()
		{
			if(!EngineInitiated)Initiate3DE();
			UseEvents=true;
			Actor3DInitilized=	NULL;
			lpTriangles=		NULL;
			lpTempTriangles=	NULL;
			lpCamera=			NULL;
			lpRenderTexture=	NULL;
			NumberOfTriangles=	NULL;
			memset(&Position,NULL,sizeof(Position));
			memset(&Rotation,NULL,sizeof(Rotation));
			memset(&RotationOriginOffset,NULL,sizeof(RotationOriginOffset));
			RenderMode=RENDERMODE_TEXTURE;
			Visible=false;
			return;
		}
		bool Actor3D_Load(string SetName,string File,unsigned long SetNumberOfTriangles,bool LoadFile,FP_Callback *lpCallbackProcedure)
		{
			Actor3DInitilized=true;
			if(!lpCallbackProcedure)UseEvents=false;
			lpCallback=lpCallbackProcedure;
			Name=SetName;
			if(LoadFile)
			{
				FILE *lpFile;
				lpFile=fopen(File.data(),"rb");
				if(!lpFile)return false;
				fseek(lpFile,0,SEEK_SET);
				fread(&NumberOfTriangles,sizeof(NumberOfTriangles),1,lpFile);
				lpTriangles=(FS_Triangle*)GlobalAlloc(GPTR,NumberOfTriangles*sizeof(FS_Triangle));
				lpTempTriangles=(FS_Triangle*)GlobalAlloc(GPTR,NumberOfTriangles*sizeof(FS_Triangle));
				
				fread(lpTriangles,sizeof(FS_Triangle),NumberOfTriangles,lpFile);
				fclose(lpFile);
			}
			else
			{
				NumberOfTriangles=SetNumberOfTriangles;
				lpTriangles=(FS_Triangle*)GlobalAlloc(GPTR,NumberOfTriangles*sizeof(FS_Triangle));
				lpTempTriangles=(FS_Triangle*)GlobalAlloc(GPTR,NumberOfTriangles*sizeof(FS_Triangle));
			}
			return true;
		}
		bool Actor3D_Pose(signed long PosX,signed long PosY,signed long PosZ,unsigned char RotX,unsigned char RotY,unsigned char RotZ,bool SetClickable,bool SetVisible)
		{
			Position.x=PosX;
			Position.y=PosY;
			Position.z=PosZ;
			Rotation.x=RotX;
			Rotation.y=RotY;
			Rotation.z=RotZ;
			Clickable=SetClickable;
			Visible=SetVisible;
			Actor3D_Calculate();
			return true;	
		}
		bool Actor3D_Calculate(void)
		{
				if(!Actor3DInitilized)return false;
				float Val,op1,op2;
				FS_Vector Origin;
				//Translation
					Origin=GetTrianglesCenter(lpTriangles,NumberOfTriangles);
					MoveTriangles(lpTempTriangles,lpTriangles,NumberOfTriangles,&Position,&Origin); 
				//Perspectiveization...wait thats not a word=)
					if(!Position.z)Position.z=1;
					op1=Position.z;
					op2=WORLD_FOCAL_LENGTH;
					Val=(op1/op2);
					Origin=GetTrianglesCenter(lpTempTriangles,NumberOfTriangles);
					ScaleTriangles(lpTempTriangles,lpTempTriangles,NumberOfTriangles,Val,Val,Val,&Origin);
					//Self Rotation
					Origin=GetTrianglesCenter(lpTempTriangles,NumberOfTriangles);
					Origin.x+=RotationOriginOffset.x;
					Origin.y+=RotationOriginOffset.y;
					Origin.z+=RotationOriginOffset.z;
					RotateTriangles(lpTempTriangles,lpTempTriangles,NumberOfTriangles,&Origin,&Rotation);
				//World Rotation
					RotateTriangles(lpTempTriangles,lpTempTriangles,NumberOfTriangles,&Origin,&lpCamera->ViewRotation);
				//2d sorting point
					zSortPoint.x=GetTrianglesCenterX(lpTempTriangles,NumberOfTriangles);
					zSortPoint.y=GetTrianglesTop(lpTempTriangles,NumberOfTriangles)+((GetTrianglesBottom(lpTempTriangles,NumberOfTriangles)-GetTrianglesTop(lpTempTriangles,NumberOfTriangles))*.75);	
			return true;
		}
		bool Actor3D_Draw(FC_Image *lpImage)
		{
			if(!Visible)return false;
			SortTriangles(lpTempTriangles,0,NumberOfTriangles-1,false);
			DrawTriangles(lpImage,lpRenderTexture,&RenderColor,lpTempTriangles,NumberOfTriangles,RenderMode); 
			if(Animating)
			{
				if(UseEvents)lpCallback(EVENT_ACTOR3D_ANIM_PULSE,OBJECT_ACTOR3D,this,NULL,NULL,MotionMessage.data());
				if(xRotAnim)
				{
					xRotTemp+=xRotInc;
					if(xIncIsNeg)
					{
						if(xRotTemp<=xRotEnd)
						{
							xRotAnim=false;
						}
						else
						{
							Rotation.x=xRotTemp;
						}
					}
					else
					{
						if(xRotTemp>=xRotEnd)
						{
							xRotAnim=false;
						}
						else
						{
							Rotation.x=xRotTemp;
						}
					}
				}
				if(yRotAnim)
				{
					yRotTemp+=yRotInc;
					if(yIncIsNeg)
					{
						if(yRotTemp<=yRotEnd)
						{
							yRotAnim=false;
						}
						else
						{
							Rotation.y=yRotTemp;
						}
					}
					else
					{
						if(yRotTemp>=yRotEnd)
						{
							yRotAnim=false;
						}
						else
						{
							Rotation.y=yRotTemp;
						}
					}
				}
				if(zRotAnim)
				{
					zRotTemp+=zRotInc;
					if(zIncIsNeg)
					{
						if(zRotTemp<=zRotEnd)
						{
							zRotAnim=false;
						}
						else
						{
							Rotation.z=zRotTemp;
						}
					}
					else
					{
						if(zRotTemp>=zRotEnd)
						{
							zRotAnim=false;
						}
						else
						{
							Rotation.z=zRotTemp;
						}
					}
				}
				if(!xRotAnim&&!yRotAnim&&!zRotAnim)Actor3D_StopAnimating(true);
			}
			if(Moving)
			{
				if(UseEvents)lpCallback(EVENT_ACTOR3D_MOVE_PULSE,OBJECT_ACTOR3D,this,NULL,NULL,MotionMessage.data());
				if(!Moving)return true;
				Position.x=(MotionPath[(unsigned long)MotionCurrentPathPoint].x);
				Position.y=(MotionPath[(unsigned long)MotionCurrentPathPoint].y);
				MotionCurrentPathPoint+=MotionStepRate;
				if(MotionCurrentPathPoint>MotionNumPathPoints)
				{
					if(lpMotionBlock->lpNextBlock)
					{
						MotionNoStartMsg=true;
						Actor3D_StartMoving(true,MotionStepRate,(FS_MotionBlock*)lpMotionBlock->lpNextBlock,MotionMessage);
						MotionNoStartMsg=false;
					}
					else
					{
						Actor3D_StopMoving(true);
					}
				}
			}
			return true;
		}
		void Actor3D_PrepareMotionBlock(unsigned long BlockIndex,signed long WalkX, signed long WalkY,FS_MotionBlock *lpNextBlock)
		{
			MotionBlock[BlockIndex].WalkX=WalkX;
			MotionBlock[BlockIndex].WalkY=WalkY;
			MotionBlock[BlockIndex].lpNextBlock=lpNextBlock;
			return;
		}
		bool Actor3D_StartMoving(bool Interupt,float SetStepRate,FS_MotionBlock *lpMBlock,string SetMotionMessage)
		{
			if(!lpMBlock)return false;
			if(Moving&&!Interupt)return false;
			MotionMessage=SetMotionMessage;
			MotionStepRate=SetStepRate;
			lpMotionBlock=lpMBlock;
			MotionNumPathPoints=ScanLinearPathSegment(&MotionPath[0],MakePoint(Position.x,Position.y),MakePoint(lpMotionBlock->WalkX,lpMotionBlock->WalkY));
			MotionCurrentPathPoint=NULL;
			Moving=true;
			if(!MotionNoStartMsg)if(UseEvents)lpCallback(EVENT_ACTOR3D_MOVE_START,OBJECT_ACTOR3D,this,NULL,NULL,MotionMessage.data());
			return true;
		}
		bool Actor3D_StopMoving(bool RelayMessage)
		{
			Moving=false;
			string TempMsg=MotionMessage;
			if(UseEvents&&RelayMessage)lpCallback(EVENT_ACTOR3D_MOVE_DONE,OBJECT_ACTOR3D,this,NULL,NULL,MotionMessage.data());
			if(EvalMsg(TempMsg,MotionMessage.data())&&(!lpMotionBlock->lpNextBlock))MotionMessage="";
			return true;
		}
		
		bool Actor3D_StartAnimating(bool Interupt,signed long StartRotX,signed long EndRotX,float IncRotX,bool AnimRotX,signed long StartRotY,signed long EndRotY,float IncRotY,bool AnimRotY,signed long StartRotZ,signed long EndRotZ,float IncRotZ,bool AnimRotZ,string SetAnimMessage)
		{
			if(!Actor3DInitilized)return false;
			if(Animating&&!Interupt)return false;
			if(Animating&&Interupt)Actor3D_StopAnimating(false);
			AnimMessage=SetAnimMessage;
			if(AnimRotX)
			{
				Rotation.x=StartRotX;
				xRotEnd=EndRotX;
				xRotInc=IncRotX;
			}
			xRotAnim=AnimRotX;
			if(AnimRotY)
			{
				Rotation.y=StartRotY;
				yRotEnd=EndRotY;
				yRotInc=IncRotY;
			}
			yRotAnim=AnimRotY;
			if(AnimRotZ)
			{
				Rotation.z=StartRotZ;
				zRotEnd=EndRotZ;
				zRotInc=IncRotZ;
			}
			zRotAnim=AnimRotZ;
			xRotTemp=StartRotX;
			yRotTemp=StartRotY;
			zRotTemp=StartRotZ;
			xIncIsNeg=false;
			yIncIsNeg=false;
			zIncIsNeg=false;
			if(xRotInc<0)xIncIsNeg=true;
			if(yRotInc<0)yIncIsNeg=true;
			if(zRotInc<0)zIncIsNeg=true;
			Animating=true;
			if(UseEvents)lpCallback(EVENT_ACTOR3D_ANIM_START,OBJECT_ACTOR3D,this,NULL,NULL,AnimMessage.data());
			return true;
		}
		bool Actor3D_StopAnimating(bool RelayMessage)
		{
			if(!Actor3DInitilized&&!Animating)return false;
			string TempMsg=AnimMessage;
			Animating=false;
			if(UseEvents&&RelayMessage)lpCallback(EVENT_ACTOR3D_ANIM_DONE,OBJECT_ACTOR3D,this,NULL,NULL,AnimMessage.data());
			if(EvalMsg(TempMsg,AnimMessage.data()))AnimMessage="";
			return true;
		}
		~FC_Actor3D()
		{
			if(Actor3DInitilized)
			{
				Actor3DInitilized=false;
				GlobalFree(lpTriangles);
				lpTriangles=NULL;
				GlobalFree(lpTempTriangles);
				lpTempTriangles=NULL;
			}
			return;
		}
};
class FC_HotSpot
{
	private:
		bool				UseEvents;
	public:
		string				Name;
		signed long			Left;
		signed long			Top;
		unsigned long		Width;
		unsigned long		Height;
		FP_Callback	*lpCallback;
		bool				Clickable;
		bool				Visible;
		POINT				zSortPoint;
		FC_HotSpot()
		{
			UseEvents=	true;
			Name=		"";
			Left=		NULL;
			Top=		NULL;
			Height=		NULL;
			Height=		NULL;
			Clickable=	true;
			Visible=	false;
			return;
		}
		bool HotSpot_Load(string SetName,FP_Callback *lpCallbackProcedure)
		{
			if(!lpCallbackProcedure)UseEvents=false;
			lpCallback=lpCallbackProcedure;
			Name=SetName;
			return true;
		}
		bool HotSpot_Pose(signed long SetLeft,signed long SetTop,unsigned long SetWidth,unsigned long SetHeight,bool SetClickable,bool SetVisible)
		{
			Left=SetLeft;
			Top=SetTop;
			Width=SetWidth;
			Height=SetHeight;
			Clickable=SetClickable;
			Visible=SetVisible;
			zSortPoint.x=Left+(Width/2);
			zSortPoint.y=Top+(Height*.75);
			return true;
		}
		bool HotSpot_HitTestPoint(POINT *lpPoint,string Message)
		{
			if(!Clickable||!Visible)return false;
			zSortPoint.x=Left+(Width/2);
			zSortPoint.y=Top+(Height*.75);
			RECT TempRect={Left,Top,Left+Width,Top+Height};
			if(PtInRect(&TempRect,*lpPoint))
			{
				if(UseEvents)lpCallback(EVENT_HOTSPOT_HIT,OBJECT_HOTSPOT,(void*)this,NULL,NULL,Message.data());
				return true;
			}
			return false;
		}
		bool HotSpot_SaveState(string GameFile,string SectorName)
		{
			WritePrivateProfileString(SectorName.data(),"HOTSPOT_A",Name.data(),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"HOTSPOT_B",&Left,sizeof(Left),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"HOTSPOT_C",&Top,sizeof(Top),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"HOTSPOT_D",&Width,sizeof(Width),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"HOTSPOT_E",&Height,sizeof(Height),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"HOTSPOT_F",&Visible,sizeof(Visible),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"HOTSPOT_G",&Clickable,sizeof(Clickable),GameFile.data());
			return true;
		}
		bool HotSpot_LoadState(string GameFile,string SectorName)
		{
			Name.resize(255);
			GetPrivateProfileString(SectorName.data(),"HOTSPOT_A","",(char*)Name.data(),255,GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"HOTSPOT_B",&Left,sizeof(Left),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"HOTSPOT_C",&Top,sizeof(Top),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"HOTSPOT_D",&Width,sizeof(Width),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"HOTSPOT_E",&Height,sizeof(Height),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"HOTSPOT_F",&Visible,sizeof(Visible),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"HOTSPOT_G",&Clickable,sizeof(Clickable),GameFile.data());
			return true;
		}

		~FC_HotSpot()
		{
			return;
		}
};
class FC_SpotLight
{	
	private:
		long			cX,cY,TempCX,TempCY,i,TempRadiusSQR;
	public:	
		string			Name;
		bool			SpotLightInitilized;
		long			Left;
		long			Top;
		unsigned long	Radius;
		unsigned char	MaxAlpha;
		bool			Radial;
		bool			Visible;
		bool			Clickable;
		bool			UseEvents;
		FS_Color		LightColor;
		POINT			zSortPoint;
		FP_Callback		*lpCallback;
		POINT			MotionPath[MAX_PATH_POINTS];
		unsigned long	MotionNumPathPoints;
		float			MotionCurrentPathPoint;
		bool			MotionNoStartMsg;
		string			AnimMessage;
		string			MotionMessage;
		float			MotionStepRate;
		FS_MotionBlock	MotionBlock[MOTION_BLOCKS];
		FS_MotionBlock	*lpMotionBlock;
		bool			Animating;
		bool			Moving;

		unsigned char	rEnd;
		float			rInc;
		float			rTemp;
		bool			rAnim;
		unsigned char	gEnd;
		float			gInc;
		float			gTemp;
		bool			gAnim;
		unsigned char	bEnd;
		float			bInc;
		float			bTemp;
		bool			bAnim;
		bool			rIncIsNeg;
		bool			gIncIsNeg;
		bool			bIncIsNeg;
		FC_SpotLight()
		{
			SpotLightInitilized=false;
			UseEvents=true;
			lpCallback=NULL;
			return;
		}
		void SpotLight_Load(string SetName,FP_Callback *lpCallbackProcedure)
		{
			if(!lpCallbackProcedure)UseEvents=false;
			lpCallback=lpCallbackProcedure;
			Name=SetName;
			SpotLightInitilized=true;
			return;
		}
		bool SpotLight_Pose(signed long SetLeft,signed long SetTop,unsigned long SetRadius,FS_Color SetLightColor,unsigned char SetMaxAlpha,bool SetRadial,bool SetClickable,bool SetVisible)
		{
			LightColor=SetLightColor;
			Left=SetLeft;
			Top=SetTop;
			Radius=SetRadius;
			Radial=SetRadial;
			MaxAlpha=SetMaxAlpha;
			Clickable=SetClickable;
			Visible=SetVisible;
			zSortPoint.x=Left;
			zSortPoint.y=Top+(Radius*.75);
			return true;
		}
		bool SpotLight_Draw(FC_Image *lpImage)
		{
			if(!Visible)return false; 
			unsigned char	Alpha;
			memset(&LightPointDrawn[0],0,LIGHT_MAXBUFX*LIGHT_MAXBUFY);
			zSortPoint.x=Left;
			zSortPoint.y=Top+(Radius*.75);
			for(i=1;i<Radius;i++)
			{
				TempRadiusSQR=i*i;
				Alpha=MaxAlpha-(i*MaxAlpha)/Radius;
				for(cX=-i;cX<i;cX++)
				{
					for(cY=-i;cY<i;cY++)
					{
						TempCX=cX;
						TempCY=cY;
						if(Radial)
						{
							TempCX*=TempCX;
							TempCY*=TempCY;
						}
						if((TempCX)+(TempCY)<=TempRadiusSQR)
						{
							if((cX+Left)>=0&&(cY+Top)>=0&&(cX+Left)<=lpImage->ImageWidth&&(cY+Top)<=lpImage->ImageHeight)
							{
								if(!LightPointDrawn[(cY+Top)*lpImage->ImageWidth+(cX+Left)])
								{							
									WritePixelAlpha(cX+Left,cY+Top,lpImage,&LightColor,Alpha);
									LightPointDrawn[(cY+Top)*lpImage->ImageWidth+(cX+Left)]=true;							
								}
							}
						}
					}
				}
			}
			if(Animating)
			{
				if(rAnim)
				{
					rTemp+=rInc;
					if(rIncIsNeg)
					{
						if(rTemp<=rEnd)
						{
							rAnim=false;
						}
						else
						{
							LightColor.R=rTemp;
						}
					}
					else
					{
						if(rTemp>=rEnd)
						{
							rAnim=false;
						}
						else
						{
							LightColor.R=rTemp;
						}
					}
				}
				if(gAnim)
				{
					gTemp+=gInc;
					if(gIncIsNeg)
					{
						if(gTemp<=gEnd)
						{
							gAnim=false;
						}
						else
						{
							LightColor.G=gTemp;
						}
					}
					else
					{
						if(gTemp>=gEnd)
						{
							gAnim=false;
						}
						else
						{
							LightColor.G=gTemp;
						}
					}
				}
				if(bAnim)
				{
					bTemp+=bInc;
					if(bIncIsNeg)
					{
						if(bTemp<=bEnd)
						{
							bAnim=false;
						}
						else
						{
							LightColor.B=bTemp;
						}
					}
					else
					{
						if(bTemp>=bEnd)
						{
							bAnim=false;
						}
						else
						{
							LightColor.B=bTemp;
						}
					}
				}
				if(!rAnim&&!gAnim&&!bAnim)SpotLight_StopAnimating(true);
			}
			if(Moving)
			{
				if(UseEvents)lpCallback(EVENT_SPOTLIGHT_MOVE_PULSE,OBJECT_SPOTLIGHT,this,NULL,NULL,MotionMessage.data());
				if(!Moving)return true;
				Left=(MotionPath[(unsigned long)MotionCurrentPathPoint].x-abs(zSortPoint.x-Left));
				Top=(MotionPath[(unsigned long)MotionCurrentPathPoint].y-abs(zSortPoint.y-Top));
				MotionCurrentPathPoint+=MotionStepRate;
				if(MotionCurrentPathPoint>MotionNumPathPoints)
				{
					if(lpMotionBlock->lpNextBlock)
					{
						MotionNoStartMsg=true;
						SpotLight_StartMoving(true,MotionStepRate,(FS_MotionBlock*)lpMotionBlock->lpNextBlock,MotionMessage);
						MotionNoStartMsg=false;
					}
					else
					{
						SpotLight_StopMoving(true);
					}
				}
			}
			return true;
		}
		void SpotLight_PrepareMotionBlock(unsigned long BlockIndex,signed long WalkX, signed long WalkY,FS_MotionBlock *lpNextBlock)
		{
			MotionBlock[BlockIndex].WalkX=WalkX;
			MotionBlock[BlockIndex].WalkY=WalkY;
			MotionBlock[BlockIndex].lpNextBlock=lpNextBlock;
			return;
		}
		bool SpotLight_StartMoving(bool Interupt,float SetStepRate,FS_MotionBlock *lpMBlock,string SetMotionMessage)
		{
			zSortPoint.x=Left;
			zSortPoint.y=Top+(Radius*.75);
			if(!lpMBlock)return false;
			if(Moving&&!Interupt)return false;
			MotionMessage=SetMotionMessage;
			MotionStepRate=SetStepRate;
			lpMotionBlock=lpMBlock;
			MotionNumPathPoints=ScanLinearPathSegment(&MotionPath[0],MakePoint(zSortPoint.x,zSortPoint.y),MakePoint(lpMotionBlock->WalkX,lpMotionBlock->WalkY));
			MotionCurrentPathPoint=NULL;
			Moving=true;
			if(!MotionNoStartMsg)if(UseEvents)lpCallback(EVENT_SPOTLIGHT_MOVE_START,OBJECT_SPOTLIGHT,this,NULL,NULL,MotionMessage.data());
			return true;
		}
		bool SpotLight_StopMoving(bool RelayMessage)
		{
			Moving=false;
			string TempMsg=MotionMessage;
			if(UseEvents&&RelayMessage)lpCallback(EVENT_SPOTLIGHT_MOVE_DONE,OBJECT_SPOTLIGHT,this,NULL,NULL,MotionMessage.data());
			if(EvalMsg(TempMsg,MotionMessage.data())&&(!lpMotionBlock->lpNextBlock))MotionMessage="";
			return true;
		}
		bool SpotLight_StartAnimating(bool Interupt,unsigned char StartR,unsigned char EndR,float IncR,bool AnimR,unsigned char StartG,unsigned char EndG,float IncG,bool AnimG,unsigned char StartB,unsigned char EndB,float IncB,bool AnimB,string SetAnimMessage)
		{
			if(Animating&&!Interupt)return false;
			AnimMessage=SetAnimMessage;
			if(AnimR)
			{
				LightColor.R=StartR;
				rTemp=StartR;
				rEnd=EndR;
				rInc=IncR;
			}
			rAnim=AnimR;
			if(AnimG)
			{
				LightColor.G=StartG;
				gTemp=StartG;
				gEnd=EndG;
				gInc=IncG;
			}
			gAnim=AnimG;
			if(AnimB)
			{
				LightColor.B=StartB;
				bTemp=StartB;
				bEnd=EndB;
				bInc=IncB;
			}
			bAnim=AnimB;
			rIncIsNeg=false;
			gIncIsNeg=false;
			bIncIsNeg=false;
			if(rInc<0)rIncIsNeg=true;
			if(gInc<0)gIncIsNeg=true;
			if(bInc<0)bIncIsNeg=true;
			Animating=true;
			if(UseEvents)lpCallback(EVENT_SPOTLIGHT_ANIM_START,OBJECT_SPOTLIGHT,this,NULL,NULL,AnimMessage.data());
			return true;
		}
		bool SpotLight_StopAnimating(bool RelayMessage)
		{
			if(!SpotLightInitilized&&!Animating)return false;
			Animating=false;
			string TempMsg=AnimMessage;
			if(UseEvents&&RelayMessage)lpCallback(EVENT_SPOTLIGHT_ANIM_DONE,OBJECT_SPOTLIGHT,this,NULL,NULL,AnimMessage.data());
			if(EvalMsg(TempMsg,AnimMessage.data()))AnimMessage="";
			return true;
		}
		bool SpotLight_HitTestPoint(POINT *lpPoint,string Message)
		{
			if(!Clickable||!Visible)return false;
			zSortPoint.x=Left;
			zSortPoint.y=Top+(Radius*.75);
			if((((lpPoint->x-Left)*(lpPoint->x-Left))+((lpPoint->y-Top)*(lpPoint->y-Top)))<(Radius*Radius))
			{
				if(UseEvents)lpCallback(EVENT_SPOTLIGHT_HIT,OBJECT_SPOTLIGHT,(void*)this,NULL,NULL,Message.data());
				return true;
			}
			return false;
		}
		bool SpotLight_SaveState(string GameFile,string SectorName)
		{
			WritePrivateProfileStruct(SectorName.data(),"SPOTLIGHT_A",&LightColor,sizeof(LightColor),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"SPOTLIGHT_B",&Left,sizeof(Left),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"SPOTLIGHT_C",&Top,sizeof(Top),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"SPOTLIGHT_D",&Radius,sizeof(Radius),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"SPOTLIGHT_E",&Radial,sizeof(Radial),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"SPOTLIGHT_F",&Visible,sizeof(Visible),GameFile.data());
			WritePrivateProfileStruct(SectorName.data(),"SPOTLIGHT_G",&Clickable,sizeof(Clickable),GameFile.data());
			return true;
		}
		bool SpotLight_LoadState(string GameFile,string SectorName)
		{
			GetPrivateProfileStruct(SectorName.data(),"SPOTLIGHT_A",&LightColor,sizeof(LightColor),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"SPOTLIGHT_B",&Left,sizeof(Left),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"SPOTLIGHT_C",&Top,sizeof(Top),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"SPOTLIGHT_D",&Radius,sizeof(Radius),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"SPOTLIGHT_E",&Radial,sizeof(Radial),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"SPOTLIGHT_F",&Visible,sizeof(Visible),GameFile.data());
			GetPrivateProfileStruct(SectorName.data(),"SPOTLIGHT_G",&Clickable,sizeof(Clickable),GameFile.data());
			return true;
		}
		~FC_SpotLight()
		{
			return;
		}
};
class FC_zBuffer
{	
	private:
		bool			UseEvents;
	public:
		string			Name;
		unsigned long	NumOfNodes;
		FP_Callback		*lpCallback;
		FS_zNode		*lpBufferNode;
		FC_zBuffer()
		{
			UseEvents=true;
			return;
		}
		bool zBuffer_Load(string SetName,unsigned long SetNumberOfNodes,FP_Callback* lpCallbackProcedure)
		{
			if(!lpCallbackProcedure)UseEvents=false;
			lpCallback=lpCallbackProcedure;
			Name=SetName;
			lpBufferNode=(FS_zNode*)GlobalAlloc(GPTR,SetNumberOfNodes*sizeof(FS_zNode));
			NumOfNodes=SetNumberOfNodes;
			return true;
		}
		bool zBuffer_HitTestNodes(POINT* lpPoint,string Message)
		{
			unsigned long i;
			FC_Actor2D		*lpActor2D;
			FC_HotSpot		*lpHotSpot;
			FC_SpotLight	*lpSpotLight;
			if(UseEvents)lpCallback(EVENT_ZBUFFER_GET_NODES,OBJECT_ZBUFFER,(void*)this,NULL,NULL,"");
			SortNodes(lpBufferNode,0,NumOfNodes-1,false);
			if(UseEvents)lpCallback(EVENT_ZBUFFER_HIT_START,OBJECT_ZBUFFER,(void*)this,NULL,NULL,"");
			for(i=0;i<NumOfNodes;i++)
			{
				switch(lpBufferNode[i].ObjectType)
				{
				case OBJECT_ACTOR2D:
					lpActor2D=(FC_Actor2D*)lpBufferNode[i].lpObjectPointer;
					if(UseEvents)lpCallback(EVENT_ZBUFFER_HIT_NODE_START,OBJECT_ZBUFFER,(void*)this,OBJECT_ACTOR2D,(void*)lpActor2D,"");
					if(lpActor2D->Actor2D_HitTestPoint(lpPoint,Message))return true;;
					if(UseEvents)lpCallback(EVENT_ZBUFFER_HIT_NODE_DONE,OBJECT_ZBUFFER,(void*)this,OBJECT_ACTOR2D,(void*)lpActor2D,"");
					break;
				case OBJECT_ACTOR3D:
					/*
					lpActor3D=(FC_Actor3D*)lpBufferNode[i].lpObjectPointer;
					if(UseEvents)lpCallback(EVENT_ZBUFFER_HIT_NODE_START,OBJECT_ZBUFFER,(void*)this,OBJECT_ACTOR3D,(void*)lpActor2D,"");
					if(lpActor2D->Actor2D_HitTestPoint(lpPoint,Message))return true;;
					if(UseEvents)lpCallback(EVENT_ZBUFFER_HIT_NODE_DONE,OBJECT_ZBUFFER,(void*)this,OBJECT_ACTOR3D,(void*)lpActor2D,"");
					*/
					break;
				case OBJECT_HOTSPOT:
					lpHotSpot=(FC_HotSpot*)lpBufferNode[i].lpObjectPointer;
					if(UseEvents)lpCallback(EVENT_ZBUFFER_HIT_NODE_START,OBJECT_ZBUFFER,(void*)this,OBJECT_HOTSPOT,(void*)lpHotSpot,"");
					if(lpHotSpot->HotSpot_HitTestPoint(lpPoint,Message))return true;
					if(UseEvents)lpCallback(EVENT_ZBUFFER_HIT_NODE_DONE,OBJECT_ZBUFFER,(void*)this,OBJECT_HOTSPOT,(void*)lpHotSpot,"");
					break;
				case OBJECT_SPOTLIGHT:
					lpSpotLight=(FC_SpotLight*)lpBufferNode[i].lpObjectPointer;
					if(UseEvents)lpCallback(EVENT_ZBUFFER_HIT_NODE_START,OBJECT_ZBUFFER,(void*)this,OBJECT_SPOTLIGHT,(void*)lpSpotLight,"");
					if(lpSpotLight->SpotLight_HitTestPoint(lpPoint,Message))return true;
					if(UseEvents)lpCallback(EVENT_ZBUFFER_HIT_NODE_DONE,OBJECT_ZBUFFER,(void*)this,OBJECT_SPOTLIGHT,(void*)lpSpotLight,"");
					break;
				}
			}
			return false;
		}
		void zBuffer_DrawNodes(FC_Image *lpImage)
		{
			unsigned long i;
			FC_Actor2D		*lpActor2D;
			FC_Actor3D		*lpActor3D;
			FC_SpotLight	*lpSpotLight;
			if(UseEvents)lpCallback(EVENT_ZBUFFER_GET_NODES,OBJECT_ZBUFFER,(void*)this,NULL,NULL,"");
			SortNodes(lpBufferNode,0,NumOfNodes-1,true);
			if(UseEvents)lpCallback(EVENT_ZBUFFER_DRAW_START,OBJECT_ZBUFFER,(void*)this,NULL,NULL,"");
			for(i=0;i<NumOfNodes;i++)
			{
				switch(lpBufferNode[i].ObjectType)
				{
				case OBJECT_ACTOR2D:
					lpActor2D=(FC_Actor2D*)lpBufferNode[i].lpObjectPointer;
					if(UseEvents)lpCallback(EVENT_ZBUFFER_DRAW_NODE_START,OBJECT_ZBUFFER,(void*)this,OBJECT_ACTOR2D,(void*)lpActor2D,"");
					lpActor2D->Actor2D_Draw(lpImage);
					if(UseEvents)lpCallback(EVENT_ZBUFFER_DRAW_NODE_DONE,OBJECT_ZBUFFER,(void*)this,OBJECT_ACTOR2D,(void*)lpActor2D,"");
					break;
				case OBJECT_ACTOR3D:
					lpActor3D=(FC_Actor3D*)lpBufferNode[i].lpObjectPointer;
					if(UseEvents)lpCallback(EVENT_ZBUFFER_DRAW_NODE_START,OBJECT_ZBUFFER,(void*)this,OBJECT_ACTOR3D,(void*)lpActor3D,"");
					lpActor3D->Actor3D_Draw(lpImage);
					if(UseEvents)lpCallback(EVENT_ZBUFFER_DRAW_NODE_DONE,OBJECT_ZBUFFER,(void*)this,OBJECT_ACTOR3D,(void*)lpActor3D,"");
					break;
				case OBJECT_SPOTLIGHT:
					lpSpotLight=(FC_SpotLight*)lpBufferNode[i].lpObjectPointer;
					if(UseEvents)lpCallback(EVENT_ZBUFFER_DRAW_NODE_START,OBJECT_ZBUFFER,(void*)this,OBJECT_SPOTLIGHT,(void*)lpSpotLight,"");
					lpSpotLight->SpotLight_Draw(lpImage);
					if(UseEvents)lpCallback(EVENT_ZBUFFER_DRAW_NODE_DONE,OBJECT_ZBUFFER,(void*)this,OBJECT_SPOTLIGHT,(void*)lpSpotLight,"");
					break;
				}
			}
			if(UseEvents)lpCallback(EVENT_ZBUFFER_DRAW_DONE,OBJECT_ZBUFFER,(void*)this,NULL,NULL,"");
		}
		void zBuffer_SetNodesVisible(bool SetVisible)
		{
			unsigned long i;
			FC_Actor2D		*lpActor2D;
			FC_Actor3D		*lpActor3D;
			FC_HotSpot		*lpHotSpot;
			FC_SpotLight	*lpSpotLight;
			for(i=0;i<NumOfNodes;i++)
			{
				switch(lpBufferNode[i].ObjectType)
				{
				case OBJECT_ACTOR2D:
					lpActor2D=(FC_Actor2D*)lpBufferNode[i].lpObjectPointer;
					lpActor2D->Visible=SetVisible;
					break;
				case OBJECT_ACTOR3D:
					lpActor3D=(FC_Actor3D*)lpBufferNode[i].lpObjectPointer;
					lpActor3D->Visible=SetVisible;
					break;
				case OBJECT_HOTSPOT:
					lpHotSpot=(FC_HotSpot*)lpBufferNode[i].lpObjectPointer;
					lpHotSpot->Visible=SetVisible;
					break;
				case OBJECT_SPOTLIGHT:
					lpSpotLight=(FC_SpotLight*)lpBufferNode[i].lpObjectPointer;
					lpSpotLight->Visible=SetVisible;
					break;
				}
			}		
		}
		~FC_zBuffer()
		{
			GlobalFree(lpBufferNode);
			lpBufferNode=NULL;
		}
};
class FC_SyncTimer
{
	private:
		bool				UseEvents;	
		bool				SyncTimerInvoked;
		unsigned long		PeriodCounter;
		unsigned long		PeriodCount;
		string				SyncMessage;
	public:
		string				Name;
		FP_Callback	*lpCallback;
	FC_SyncTimer()
	{
		SyncTimerInvoked=	false;
		UseEvents=			true;
		PeriodCount=		NULL;
		PeriodCounter=		NULL;
		return;
	}
	bool SyncTimer_Load(string SetName,FP_Callback *lpCallbackProcedure)
	{
		Name=SetName;
		if(!lpCallbackProcedure)UseEvents=false;
		lpCallback=lpCallbackProcedure;
		return true;
	}
	bool SyncTimer_Start(bool Interupt,unsigned long SetPeriod,string SetSyncMessage)
	{
		if(SyncTimerInvoked&&!Interupt)return false;
		SyncMessage=		SetSyncMessage;
		PeriodCount=		SetPeriod;
		PeriodCounter=		NULL;
		SyncTimerInvoked=	true;
		lpCallback(EVENT_SYNCTIMER_PERIOD_START,OBJECT_SYNCTIMER,this,NULL,NULL,SyncMessage.data());
		return true;
	}
	bool SyncTimer_Stop(bool RelayMessage)
	{
		SyncTimerInvoked=	false;
		if(RelayMessage)lpCallback(EVENT_SYNCTIMER_PERIOD_DONE,OBJECT_SYNCTIMER,this,NULL,NULL,SyncMessage.data());
		SyncMessage=		"";
		return RelayMessage;
	}
	void SyncTimer_Pulse(void)
	{
		if(!SyncTimerInvoked)return;
		PeriodCounter++;
		lpCallback(EVENT_SYNCTIMER_PERIOD_PULSE,OBJECT_SYNCTIMER,this,NULL,NULL,SyncMessage.data());
		if(PeriodCounter>=PeriodCount)SyncTimer_Stop(true);	
		return;
	}
};
class FC_SubTitle
{
	public:
		bool			UseEvents;
		FP_Callback		*lpCallback;
		string			Name;
		string			Body[MAX_SUBTITLE_ENTRIES];
		string			DialogMessage[MAX_SUBTITLE_ENTRIES];
		FS_Color		Color[MAX_SUBTITLE_ENTRIES];
		unsigned long	Period[MAX_SUBTITLE_ENTRIES];
		bool			Relay[MAX_SUBTITLE_ENTRIES];
		unsigned long	Counter;
		unsigned long	DrawTextFlags;
		unsigned long	OldTextColor;
		unsigned long	CurrentDialog;
		unsigned long	NumberOfDialogs;
		RECT			Rect;
		bool			Showing;
		bool			Visible;
	FC_SubTitle()
	{
		Showing=		false;
		UseEvents=		true;
		lpCallback=		NULL;
		Counter=		NULL;
		CurrentDialog=	NULL;
		NumberOfDialogs=NULL;
		return;
	}
	bool SubTitle_Load(string SetName,FP_Callback *lpCallbackProcedure)
	{
		Name=SetName;
		if(!lpCallbackProcedure)UseEvents=false;
		lpCallback=lpCallbackProcedure;
		return true;
	}
	bool SubTitle_Pose(long SetLeft,long SetTop,unsigned long SetWidth,unsigned long SetHeight,unsigned long SetDrawTextFlags,bool SetVisible)
	{
		SetRect(&Rect,SetLeft,SetTop,SetLeft+SetWidth,SetTop+SetHeight);
		DrawTextFlags=SetDrawTextFlags;
		Visible=SetVisible;
		return true;
	}
	bool SubTitle_Draw(FC_Image *lpImage)
	{
		if(!Visible||!Showing)return false;
		unsigned char i;
		for(i=0;i<5;i++)
		{
			OldTextColor=SetTextColor(lpImage->ImageDC,RGB((Color[CurrentDialog].R*i)/5,(Color[CurrentDialog].G*i)/5,(Color[CurrentDialog].B*i)/5));
			DrawText(lpImage->ImageDC,Body[CurrentDialog].data(),-1,&Rect,DrawTextFlags);
			SetTextColor(lpImage->ImageDC,OldTextColor);
			OffsetRect(&Rect,1,1);
		}
		OffsetRect(&Rect,-i,-i);
		if(Counter>=Period[CurrentDialog])
		{
			Counter=NULL;
			if(CurrentDialog>=NumberOfDialogs)
			{
				SubTitle_StopShowDialog();
			}
			else
			{
				SubTitle_SkipCurrentDialog();
			}
		}
		else
		{
			Counter++;
		}
		return true;
	}
	void SubTitle_PrepareDialog(unsigned char DialogIndex,string SetBody,FS_Color SetColor,unsigned long SetPeriod,string SetDialogMessage,bool RelayMessage)
	{
		if(DialogIndex<MAX_SUBTITLE_ENTRIES)
		{
			Body[DialogIndex]=SetBody;
			DialogMessage[DialogIndex]=SetDialogMessage;
			Period[DialogIndex]=SetPeriod;
			memcpy(&Color[DialogIndex],&SetColor,sizeof(FS_Color));
			Relay[DialogIndex]=RelayMessage;
		}
		return;
	}
	bool SubTitle_SkipCurrentDialog(void)
	{
		if(Relay[CurrentDialog])if(UseEvents)lpCallback(EVENT_SUBTITLE_SHOW_PULSE,OBJECT_SUBTITLE,this,NULL,NULL,DialogMessage[CurrentDialog].data());
		CurrentDialog++;
		Counter=0;
		return true;
	}
	bool SubTitle_StartShowDialog(unsigned long SetNumberOfDialogs)
	{
		CurrentDialog=0;
		NumberOfDialogs=SetNumberOfDialogs;
		Showing=true;
		if(UseEvents)lpCallback(EVENT_SUBTITLE_SHOW_START,OBJECT_SUBTITLE,this,NULL,NULL,NULL);
		return true;
	}
	void SubTitle_StopShowDialog(void)
	{
		Counter=NULL;
		Showing=false;
		if(UseEvents)lpCallback(EVENT_SUBTITLE_SHOW_DONE,OBJECT_SUBTITLE,this,NULL,NULL,NULL);
		return;
	}
};
class FC_ImageFont
{
	private:
		HFONT	hOldFont,hFont;
	public:
		string	Name;
		LOGFONT	LFont;
	void ImageFont_Load(string SetName,long SetFontWidth,long SetFontHeight,long SetFontRotation,long SetFontWeight,bool SetFontItalic,bool SetFontUnderline,bool SetFontStrikeOut,unsigned char SetFontCharacterSet,unsigned char SetFontOutput,unsigned char SetFontQuality,unsigned char SetFontPitch,unsigned char SetFontFamily,string SetFontTypeFaceName)
	{
		Name=SetName;
		LFont.lfClipPrecision=128;
		LFont.lfEscapement=SetFontRotation*10;
		LFont.lfHeight=SetFontHeight;
		LFont.lfWidth=SetFontWidth;
		LFont.lfItalic=SetFontItalic;
		LFont.lfUnderline=SetFontUnderline;
		LFont.lfStrikeOut=SetFontStrikeOut;
		LFont.lfQuality=SetFontQuality;
		LFont.lfCharSet=SetFontCharacterSet;
		LFont.lfOutPrecision=SetFontOutput;
		LFont.lfOrientation=0x0;
		LFont.lfPitchAndFamily=SetFontPitch|SetFontFamily;
		LFont.lfWeight=SetFontWeight;
		strcpy(LFont.lfFaceName,SetFontTypeFaceName.data());
	}
	void ImageFont_RotateFont(long SetFontRotation)
	{
		LFont.lfEscapement=SetFontRotation*10;
	}
	void ImageFont_SizeFont(long SetFontWidth,long SetFontHeight)
	{
		LFont.lfWidth=SetFontWidth;
		LFont.lfHeight=SetFontHeight;
	}
	void ImageFont_BeginSetFont(FC_Image *lpImage)
	{
		hFont=CreateFontIndirect(&LFont);
		hOldFont=(HFONT)SelectObject(lpImage->ImageDC,hFont);
	}
	void ImageFont_EndSetFont(FC_Image *lpImage)
	{
		SelectObject(lpImage->ImageDC,hOldFont);
		if(hFont)
		{
			DeleteObject(hFont);
			hFont=0;
		}
	}
	void ImageFont_BeginSetFontDC(HDC hDC)
	{
		hFont=CreateFontIndirect(&LFont);
		hOldFont=(HFONT)SelectObject(hDC,hFont);
	}
	void ImageFont_EndSetFontDC(HDC hDC)
	{
		SelectObject(hDC,hOldFont);
		if(hFont)
		{
			DeleteObject(hFont);
			hFont=0;
		}
	}
	~FC_ImageFont()
	{
		if(hFont)
		{
			DeleteObject(hFont);
			hFont=NULL;
		}
	}
};
class FC_Movie
{
	private:
		bool				MovieInitilized;
		bool				UseEvents;
		bool				MovieOpen;
		bool				MoviePlaying;
		char				CmdString[255];
		string				MovieMessage;	
	public:
		FP_Callback *lpCallback;
		string				Name;
	FC_Movie()
	{
		MovieInitilized=false;
		MovieOpen=false;
		MoviePlaying=false;
		UseEvents=true;
		return;
	}
	bool Movie_Load(string SetName,FP_Callback *lpCallbackProcedure)
	{
		Name=SetName;
		if(!lpCallbackProcedure)UseEvents=false;
		lpCallback=lpCallbackProcedure;
		MovieInitilized=true;
		return true;
	}
	bool Movie_Open(string File,unsigned char MediaType,FC_Window *lpParent)
	{
		MCIERROR	MciError;
		if(MovieOpen)return false;
		if(lpParent)
		{
			sprintf((char*)CmdString,"Open %s Type AviVideo Alias %s parent %d Style 1073741824",File.data(),Name.data(),lpParent->hWnd);
		}
		else
		{
			sprintf((char*)CmdString,"Open %s Type AviVideo Alias %s",File.data(),Name.data());			
		}
		MciError=mciSendString((const char*)CmdString,NULL,NULL,NULL);
		MovieOpen=true;
		return true;
	}
	bool Movie_Pose(RECT PositionRect)
	{
		if(!MovieOpen)return false;
		MCIERROR	MciError;
		sprintf((char*)CmdString,"Put %s window at %d %d %d %d",Name.data(),PositionRect.left,PositionRect.top,PositionRect.right-PositionRect.left,PositionRect.bottom-PositionRect.top);
		MciError=mciSendString((const char*)CmdString,NULL,NULL,NULL);
		return true;
	}
	bool Movie_Seek(unsigned char Method,unsigned long Arbitrary)
	{
		if(!MovieOpen)return false;
		MCIERROR	MciError;
		switch(Method)
		{
		case MOVIE_SEEK_BEGINING:
			sprintf((char*)CmdString,"Seek %s to start",Name.data());
			break;
		case MOVIE_SEEK_ARBITRARY:
			sprintf((char*)CmdString,"Seek %s to %d",Name.data(),Arbitrary);
			break;
		case MOVIE_SEEK_END:
			sprintf((char*)CmdString,"Seek %s to end",Name.data());
			break;
		}
		MciError=mciSendString((const char*)CmdString,NULL,NULL,NULL);
		return true;
	}
	bool Movie_Step(signed long StepAmount)
	{
		MCIERROR	MciError;
		if(!MovieOpen||!StepAmount)return false;
		if(StepAmount<0)
		{
			sprintf((char*)CmdString,"Step %s reverse by %d",Name.data(),abs(StepAmount));			
		}
		else
		{
			sprintf((char*)CmdString,"Step %s by %d",Name.data(),StepAmount);			
		}
		MciError=mciSendString((const char*)CmdString,NULL,NULL,NULL);
		return true;
	}
	bool Movie_Play(string Message)
	{
		if(!MovieOpen)return false;
		MCIERROR	MciError;
		MovieMessage=Message;
		sprintf((char*)CmdString,"Play %s",Name.data());
		MciError=mciSendString((const char*)CmdString,NULL,NULL,NULL);
		MoviePlaying=true;
		if(UseEvents)lpCallback(EVENT_MOVIE_START,OBJECT_MOVIE,this,NULL,NULL,MovieMessage.data());
		return true;
	}
	bool Movie_Pause(void)
	{
		if(!MovieOpen)return false;
		MCIERROR	MciError;
		sprintf((char*)CmdString,"Pause %s",Name.data());
		MciError=mciSendString((const char*)CmdString,NULL,NULL,NULL);
		MoviePlaying=false;
		return true;
	}
	bool Movie_Resume(void)
	{
		if(MoviePlaying||!MovieOpen)return false;
		MCIERROR	MciError;
		sprintf((char*)CmdString,"Resume %s",Name.data());
		MciError=mciSendString((const char*)CmdString,NULL,NULL,NULL);
		MoviePlaying=true;
		return true;
	}
	bool Movie_Stop(void)
	{
		if(!MovieOpen)return false;
		MCIERROR	MciError;
		sprintf((char*)CmdString,"Stop %s",Name.data());
		MciError=mciSendString((const char*)CmdString,NULL,NULL,NULL);
		MoviePlaying=false;
		return true;
	}
	bool Movie_IsPlaying(void)
	{
		return MoviePlaying;
	}
	bool Movie_Close(bool RelayMessage)
	{
		if(!MovieOpen)return false;
		MCIERROR	MciError;
		sprintf((char*)CmdString,"Close %s",Name.data());
		MciError=mciSendString((const char*)CmdString,NULL,NULL,NULL);
		MovieOpen=false;
		MoviePlaying=false;
		if(UseEvents)lpCallback(EVENT_MOVIE_DONE,OBJECT_MOVIE,this,NULL,NULL,MovieMessage.data());
		return true;
	}
	unsigned long Movie_GetLength(void)
	{
		if(!MovieOpen)return false;
		MCIERROR	MciError;
		sprintf((char*)CmdString,"Status %s Length",Name.data());
		MciError=mciSendString((const char*)CmdString,&CmdString[0],255,NULL);	
		return atol(&CmdString[0]);
	}
	unsigned long Movie_GetPosition(void)
	{
		if(!MovieOpen)return false;
		MCIERROR	MciError;
		sprintf((char*)CmdString,"Status %s Position",Name.data());
		MciError=mciSendString((const char*)CmdString,&CmdString[0],255,NULL);	
		return atol(&CmdString[0]);
	}
	void Movie_Pulse(void)
	{
		if(UseEvents)lpCallback(EVENT_MOVIE_PULSE,OBJECT_MOVIE,this,NULL,NULL,MovieMessage.data());
		if(!MovieOpen||!MoviePlaying)return;
		if(!(Movie_GetLength()-Movie_GetPosition()))Movie_Close(true);
		return;
	}
	~FC_Movie()
	{
		Movie_Close(false);
		MovieInitilized=false;
		return;
	}
};
class FC_BlackMagic
{
	public:
		string				Name;
		long				ImageBufferWidth;
		long				ImageBufferHeight;
		unsigned char		MagicType;
		FC_Image	MagicBuffer;
		FC_Image	*lpMagicMask;
		FS_Color	MagicMaskColor;
		RECT				MagicArea;
		bool				UseMask;
		bool				WaveIncreasing;
		float				WaveMin;
		float				WaveMax;
		float				WavePosition;
		bool				UseSine;
		FC_BlackMagic()
		{
			UseSine=false;
			UseMask=true;
			WaveMin=5;
			WaveMax=10;
			WavePosition=WaveMin;
			return;			
		}
		bool BlackMagic_Load(string SetName,unsigned char SetMagicType,unsigned long SetImageBufferWidth,long SetImageBufferHeight,RECT SetMagicArea,FC_Image *lpSetMagicMask,FS_Color *lpSetMagicMaskColor)
		{
			if(!lpSetMagicMask||!lpSetMagicMaskColor)UseMask=false;
			lpMagicMask=lpSetMagicMask;
			if(lpSetMagicMaskColor)memcpy(&MagicMaskColor,lpSetMagicMaskColor,sizeof(FS_Color));
			MagicType=SetMagicType;
			MagicBuffer.Image_Load("MagicBuffer",SetImageBufferWidth,SetImageBufferHeight,false);
			memcpy(&MagicArea,&SetMagicArea,sizeof(RECT));
			return true;
		}
		bool BlackMagic_Draw(FC_Image *lpImage)
		{

			float sineval,sinetemp,WavePosDiv2=(WavePosition/2);
			FS_Color TempColor;
			long x=0,y=0;	
			switch(MagicType)
			{
			case BLACKMAGIC_TYPE_RIVER:
				BitBlt(MagicBuffer.ImageDC,MagicArea.left,MagicArea.top,MagicArea.right-MagicArea.left,MagicArea.bottom-MagicArea.top,lpImage->ImageDC,MagicArea.left,MagicArea.top,SRCCOPY);
				x=MagicArea.left;

				while(x<MagicArea.right)
				{
					if(UseSine)
					{
						sinetemp=sin((x+WavePosition)/5);
					}
					else
					{
						sinetemp=cos((x+WavePosition)/5);
					}
						y=MagicArea.top;
						while(y<MagicArea.bottom)
						{
							sineval=sinetemp+y;
							UseSine=!UseSine;
							if(sineval<MagicArea.top)sineval=MagicArea.top;
							if(sineval>MagicArea.bottom)sineval=MagicArea.bottom;
							if(UseMask)
							{
								ReadPixel(x,sineval,lpMagicMask,&TempColor);
								if(CompareColor(&TempColor,&MagicMaskColor))
								{
									ReadPixel(x,y,&MagicBuffer,&TempColor);
									WritePixel(x,sineval,lpImage,&TempColor);	
								}
							}
							else
							{
								ReadPixel(x,y,&MagicBuffer,&TempColor);
								WritePixel(x,sineval,lpImage,&TempColor);
							}
							y++;
						}
					x++;
				}
				WavePosition+=(64/WaveMax);
				if(WavePosition>=64)WavePosition=0;
				return true;
			}
			return true;
		}
		~FC_BlackMagic()
		{
			return;
		}
};
bool EvalMsg(string String,const char * lpString)
{
	if(!_stricmp(String.data(),lpString))return true;
	return false;
}
string StrCmbRet(string String1,string String2)
{
	string RetString=String1+String2;
	return RetString;
}
long GetRandNumber(long Lower,long Higher)
{
	Higher-=Lower;
	if(!Higher)return 0;
	return (rand()%Higher)+Lower;
}
FS_Color MakeColor(unsigned char R,unsigned char G,unsigned char B)
{
	FS_Color TempColor={B,G,R};
	return TempColor;
}
RECT MakeDeviceRect(signed long Left,signed long Top,signed long Right,signed long Bottom)
{
	RECT TempRect={Left,Top,Right,Bottom};
	return TempRect;
}
RECT MakeNormalRect(signed long Left,signed long Top,unsigned long Width,unsigned long Height)
{
	RECT TempRect={Left,Top,Left+Width,Top+Height};
	return TempRect;
}
RECT GetScreenRect(void)
{
	RECT TempRect;
	SetRect(&TempRect,0,0,GetSystemMetrics(SM_CXSCREEN),GetSystemMetrics(SM_CYSCREEN));
	return TempRect;
}
RECT CenterRect(RECT OuterRect,RECT RectToCenter)
{
	RECT TempRect;
	CopyRect(&TempRect,&RectToCenter);
	RectToCenter.left=(OuterRect.left+((OuterRect.right-OuterRect.left)/2))-((RectToCenter.right-RectToCenter.left)/2);
	RectToCenter.top=(OuterRect.top+((OuterRect.bottom-OuterRect.top)/2))-((RectToCenter.bottom-RectToCenter.top)/2);
	RectToCenter.right=RectToCenter.left+(TempRect.right-TempRect.left);
	RectToCenter.bottom=RectToCenter.top+(TempRect.bottom-TempRect.top);
	return RectToCenter;
}
POINT MakePoint(signed long Left,signed long Top)
{
	POINT TempPoint={Left,Top};
	return TempPoint;
}
void ConvertLongToRGB(FS_Color *lpColor,unsigned long Color)
{
	lpColor->R=(unsigned char)Color;
	lpColor->G=(unsigned char)Color>>8;
	lpColor->B=(unsigned char)Color>>16;
	return;
}
bool CompareColor(FS_Color *lpColor1,FS_Color *lpColor2)
{
	if((lpColor1->R==lpColor2->R)&&(lpColor1->G==lpColor2->G)&&(lpColor1->B==lpColor2->B))return true;
	return false;
}
void SortNodes(FS_zNode Nodes[],long start,long count,bool asc)
{
	long L=start;
	long R=count;
	char flag=1;
	if(asc)flag=-1;
	if(R>L)
	{
		long i, j;
		FS_zNode temp;
		i=L-1;
		j=R;
		for(;;)
		{
			long cmp;

			do
			{
				cmp=Nodes[R].zSortPoint-Nodes[++i].zSortPoint;
				cmp*=flag;
			}
			while (cmp<0);

			while (j>0)
			{
				long cmp2=Nodes[R].zSortPoint-Nodes[--j].zSortPoint;
				cmp2 *= flag;
				if(cmp2<=0)break;
			}
			if(i>=j)break;
			temp=Nodes[i];
			Nodes[i]=Nodes[j];
			Nodes[j]=temp;
		}
		temp=Nodes[i];
		Nodes[i]=Nodes[R];
		Nodes[R]=temp;
		SortNodes(Nodes,L,i-1,asc);
		SortNodes(Nodes,i+1,R,asc);
	}
	return;
}
void SetWindowsDisplayMode(unsigned long ScreenWidth,unsigned long ScreenHeight,unsigned char ColorDepth)
{
	long	lRet;
	DEVMODE DevMode;
	lRet=EnumDisplaySettings(0,0,&DevMode);
	DevMode.dmFields=DM_PELSWIDTH|DM_PELSHEIGHT|DM_BITSPERPEL;
	DevMode.dmPelsWidth=ScreenWidth;
	DevMode.dmPelsHeight=ScreenHeight;
	DevMode.dmBitsPerPel=ColorDepth;
	lRet=ChangeDisplaySettings(&DevMode,0);
	return;
}
void RestoreWindowsDisplayMode(void)
{
	ChangeDisplaySettings(NULL,0);
	return;
}
void __forceinline WritePixel(signed long x,signed long y,FC_Image *lpImage,FS_Color *lpColor)
{
	if(x>-1&&y>-1&&x<lpImage->ImageWidth&&y<lpImage->ImageHeight)
	{	
		unsigned char *lpByte=(unsigned char*)&lpImage->lpImagePixels[y*lpImage->ImageWidth+x];
		*lpByte=lpColor->B;
		lpByte++;
		*lpByte=lpColor->G;
		lpByte++;
		*lpByte=lpColor->R;
	}
}
void __forceinline ReadPixel(signed long x,signed long y,FC_Image *lpImage,FS_Color *lpColor)
{
	if(x>-1&&y>-1&&x<lpImage->ImageWidth&&y<lpImage->ImageHeight)
	{
		unsigned char *lpByte=(unsigned char*)&lpImage->lpImagePixels[y*lpImage->ImageWidth+x];
		lpColor->B=*lpByte;
		lpByte++;
		lpColor->G=*lpByte;
		lpByte++;
		lpColor->R=*lpByte;
	}
}
void __forceinline WritePixelAlpha(signed long x,signed long y,FC_Image *lpImage,FS_Color *lpColor,unsigned char Alpha)
{
	if(x>-1&&y>-1&&x<lpImage->ImageWidth&&y<lpImage->ImageHeight)
	{	
		unsigned char *lpByte=(unsigned char*)&lpImage->lpImagePixels[y*lpImage->ImageWidth+x];
		
		*lpByte=(Alpha*(lpColor->B-*lpByte)>>8)+*lpByte;
		lpByte++;
		*lpByte=(Alpha*(lpColor->G-*lpByte)>>8)+*lpByte;
		lpByte++;
		*lpByte=(Alpha*(lpColor->R-*lpByte)>>8)+*lpByte;
	}
}
bool __forceinline WriteLine(long x1,long y1,long x2,long y2,FC_Image *lpImage,FS_Color *lpColor)
{
	long dx,dy,long_d,short_d,d,add_dh,add_dl,inc_xh,inc_yh,inc_xl,inc_yl,i=0;
	dx=x2-x1;
	dy=y2-y1;
	if(dx<0)
	{
		dx=-dx;
		inc_xh=-1;
		inc_xl=-1;
	}
	else	
	{
		inc_xh=1;
		inc_xl=1;
	}
	if(dy<0)
	{
		dy=-dy;
		inc_yh=-1;
		inc_yl=-1;
	}
	else
	{
		inc_yh=1;
		inc_yl=1;
	}
	if(dx>dy)
	{
		long_d=dx;
		short_d=dy;
		inc_yl=0;
	}
	else
	{
		long_d=dy;
		short_d=dx;
		inc_xl=0;
	}
	d=2*short_d-long_d;
	add_dl=2*short_d;
	add_dh=2*short_d-2*long_d;
	while(i<=long_d)
	{
		if(x1>-1&&y1>-1&&x1<lpImage->ImageWidth&&y1<lpImage->ImageHeight)
		{	
			unsigned char *lpByte=(unsigned char*)&lpImage->lpImagePixels[y1*lpImage->ImageWidth+x1];
			*lpByte=lpColor->B;
			lpByte++;
			*lpByte=lpColor->G;
			lpByte++;
			*lpByte=lpColor->R;
		}
		if(d>=0)
		{
			x1+=inc_xh;
			y1+=inc_yh;
			d+=add_dh;
		}
		else
		{
			x1+=inc_xl;
			y1+=inc_yl;
			d+=add_dl;
		}
		i++;
	}
	return true;
}
bool __forceinline WriteTextureLine(long x1,long y1,long x2,long y2,FC_Image *lpImage,FC_Image *lpTexture)
{
	FS_Color Color1;
	long startx=x1,starty=y1;
	long dx,dy,long_d,short_d,d,add_dh,add_dl,inc_xh,inc_yh,inc_xl,inc_yl,i=0;
	dx=x2-x1;
	dy=y2-y1;
	if(dx<0)
	{
		dx=-dx;
		inc_xh=-1;
		inc_xl=-1;
	}
	else	
	{
		inc_xh=1;
		inc_xl=1;
	}
	if(dy<0)
	{
		dy=-dy;
		inc_yh=-1;
		inc_yl=-1;
	}
	else
	{
		inc_yh=1;
		inc_yl=1;
	}
	if(dx>dy)
	{
		long_d=dx;
		short_d=dy;
		inc_yl=0;
	}
	else
	{
		long_d=dy;
		short_d=dx;
		inc_xl=0;
	}
	d=2*short_d-long_d;
	add_dl=2*short_d;
	add_dh=2*short_d-2*long_d;
	while(i<=long_d)
	{
		ReadPixel(abs(x1-startx),abs(y1-starty),lpTexture,&Color1);
		WritePixel(x1,y1,lpImage,&Color1);		
		if(d>=0)
		{
			x1+=inc_xh;
			y1+=inc_yh;
			d+=add_dh;
		}
		else
		{
			x1+=inc_xl;
			y1+=inc_yl;
			d+=add_dl;
		}
		i++;
	}
	return true;
}
void ImageTint(FC_Image *lpImage,bool RedOFF,bool GreenOFF,bool BlueOFF)
{
	unsigned long	i=0;
	unsigned char	*lpPixelByte=(unsigned char*)lpImage->lpImagePixels;
	while(i<lpImage->ImageSizePixels)
	{
		if(BlueOFF)*lpPixelByte=0;
		lpPixelByte++;
		if(GreenOFF)*lpPixelByte=0;
		lpPixelByte++;
		if(RedOFF)*lpPixelByte=0;
		lpPixelByte++;
		i++;
	}
	return;
}
void ImageFade(FC_Image *lpImage,FS_Color *lpColor,unsigned char Alpha)
{
	unsigned long i=0;
	unsigned char *lpByte=(unsigned char*)lpImage->lpImagePixels;
	while(i<lpImage->ImageSizePixels)
	{
		*lpByte=(Alpha*(lpColor->B-*lpByte)>>8)+*lpByte;
		lpByte++;
		*lpByte=(Alpha*(lpColor->G-*lpByte)>>8)+*lpByte;
		lpByte++;
		*lpByte=(Alpha*(lpColor->R-*lpByte)>>8)+*lpByte;
		lpByte++;
		i++;
	}
	return;
}
void ImageAntiAlias(FC_Image *lpImage)
{
	unsigned long x,y;
	FS_Color *lpColor1,*lpColor2;
	y=0;
	while(y<lpImage->ImageHeight-1)
	{
		x=0;
		while(x<lpImage->ImageWidth)
		{
			lpColor1=&lpImage->lpImagePixels[y*lpImage->ImageWidth+x];
			lpColor2=&lpImage->lpImagePixels[(y+1)*lpImage->ImageWidth+x];
			lpColor1->R=(lpColor1->R+lpColor2->R)/2;
			lpColor1->G=(lpColor1->G+lpColor2->G)/2;
			lpColor1->B=(lpColor1->B+lpColor2->B)/2;
			x++;
		}
		y++;
	}
	return;
}
/*
void DrawToolTip(FC_Image *lpImage,long x,long y,string Caption,unsigned long TextWidth,unsigned long TextHeight,unsigned long uFormat,bool PaintBack,HBRUSH BackBrush,bool PaintEdge,HBRUSH EdgeBrush,FS_Color *lpTextColor)
{
	RECT		TextRect={x,y,x,y};
	COLORREF	OldColor;
	DrawText(lpImage->ImageDC,Caption.data(),-1,&TextRect,uFormat|DT_CALCRECT);
	if(TextWidth!=0||TextHeight!=0)
	{
		TextRect.right=TextRect.left+TextWidth;
		TextRect.bottom=TextRect.top+TextHeight;
	}
	InflateRect(&TextRect,4,4);
	if(PaintBack)FillRect(lpImage->ImageDC,&TextRect,BackBrush);
	if(PaintEdge)FrameRect(lpImage->ImageDC,&TextRect,EdgeBrush);
	if(lpTextColor)OldColor=SetTextColor(lpImage->ImageDC,RGB(lpTextColor->R,lpTextColor->G,lpTextColor->B)); 
	DrawText(lpImage->ImageDC,Caption.data(),-1,&TextRect,uFormat);
	InflateRect(&TextRect,-2,-2);
	if(lpTextColor)SetTextColor(lpImage->ImageDC,OldColor);
}

void DrawProgressBar(FC_Image *lpImage,RECT Rect,string Caption,unsigned long uFormat,HBRUSH BarBrush,unsigned long BorderEdge,FS_Color *lpTextColor,unsigned long Value,unsigned long Max)
{
	RECT		OldRect;
	COLORREF	OldColor;
	DrawEdge(lpImage->ImageDC,&Rect,BorderEdge,BF_RECT);
	InflateRect(&Rect,-2,-2);
	CopyRect(&OldRect,&Rect);
	Rect.right=Rect.left+((Value*(Rect.right-Rect.left))/Max);
	FillRect(lpImage->ImageDC,&Rect,BarBrush);
	OldColor=SetTextColor(lpImage->ImageDC,RGB(lpTextColor->R,lpTextColor->G,lpTextColor->B)); 
	DrawText(lpImage->ImageDC,Caption.data(),-1,&OldRect,uFormat);
	SetTextColor(lpImage->ImageDC,OldColor);
}
void DrawProgressBarFloat(FC_Image *lpImage,RECT Rect,string Caption,unsigned long uFormat,HBRUSH BarBrush,unsigned long BorderEdge,FS_Color *lpTextColor,float Value,float Max)
{
	RECT		OldRect;
	COLORREF	OldColor;
	DrawEdge(lpImage->ImageDC,&Rect,BorderEdge,BF_RECT);
	InflateRect(&Rect,-2,-2);
	CopyRect(&OldRect,&Rect);
	Rect.right=Rect.left+((Value*(Rect.right-Rect.left))/Max);
	FillRect(lpImage->ImageDC,&Rect,BarBrush);
	OldColor=SetTextColor(lpImage->ImageDC,RGB(lpTextColor->R,lpTextColor->G,lpTextColor->B)); 
	DrawText(lpImage->ImageDC,Caption.data(),-1,&OldRect,uFormat);
	SetTextColor(lpImage->ImageDC,OldColor);
}
void DrawSpotLight(FC_Image *lpImage,FS_SpotLight *lpLight)
{
	if(!lpLight->Visible||!VEO_LIGHT_ENABLED)return; 
	unsigned long		LightGradSteps=lpLight->LightRadius/VEO_LIGHT_INTERPOLATION;
	long				cX,cY,TempCX,TempCY,i,TempRadius=0,TempRadiusSQR;
	FS_Color	Color;
	unsigned short		R,G,B;
	bool				*lpDrawn=(bool*)GlobalAlloc(GPTR,lpImage->ImageSizePixels);
	for(i=1;i<LightGradSteps;i++)
	{
		TempRadius=lpLight->LightRadius/LightGradSteps*i;
		TempRadiusSQR=TempRadius*TempRadius;
		for(cX=-TempRadius;cX<TempRadius;cX+=VEO_LIGHT_RESOLUTION)
		{
			for(cY=-TempRadius;cY<TempRadius;cY+=VEO_LIGHT_RESOLUTION)
			{
				TempCX=cX;
				TempCY=cY;
				if(lpLight->LightRadial)
				{
					TempCX*=TempCX;
					TempCY*=TempCY;
				}
				if((TempCX)+(TempCY)<=TempRadiusSQR)
				{
					if((cX+lpLight->LightPoint.x)>=0&&(cY+lpLight->LightPoint.y)>=0&&(cX+lpLight->LightPoint.x)<=lpImage->ImageWidth&&(cY+lpLight->LightPoint.y)<=lpImage->ImageHeight)
					{
						if(!lpDrawn[(cY+lpLight->LightPoint.y)*lpImage->ImageWidth+(cX+lpLight->LightPoint.x)])
						{							
							ReadPixel(cX+lpLight->LightPoint.x,cY+lpLight->LightPoint.y,lpImage,&Color);
							R=Color.R;G=Color.G;B=Color.B;
							R+=lpLight->LightColor.R*(LightGradSteps-i);
							if(R>255)
							{Color.R=255;}
							else
							{Color.R=R;}
							G+=lpLight->LightColor.G*(LightGradSteps-i);
							if(G>255)
							{Color.G=255;}
							else
							{Color.G=G;}
							B+=lpLight->LightColor.B*(LightGradSteps-i);
							if(B>255)
							{Color.B=255;}
							else
							{Color.B=B;}
							WritePixel(cX+lpLight->LightPoint.x,cY+lpLight->LightPoint.y,lpImage,&Color);
							lpDrawn[(cY+lpLight->LightPoint.y)*lpImage->ImageWidth+(cX+lpLight->LightPoint.x)]=true;							
						}
					}
				}
			}
		}
	}
	GlobalFree(lpDrawn);
	return;
}
void DrawElectricArc(FC_Image *lpImage,unsigned short power,unsigned short subPower,long startX,long startY,long endX,short AngleMin,short AngleMax,FS_Color *lpColorLO,FS_Color *lpColorHI)
{
	FS_Color ColorCmb;
	long sX[100],sY[100],i=0,i2=0,newX=0,newY=0,usePower=0,angle=0,oldAngle=0,powerL=0,oldX=0,oldY=0;
	oldX=startX;
	oldY=startY;
	powerL=power;
	sX[0]=oldX;
	sY[0]=oldY;
	oldAngle=0;
	for(i=1;i<100;i++)
	{
		if(endX==-1)
		{
			while(angle==oldAngle)
			{
				angle=(short)(GetRandNumber(AngleMin,AngleMax))+ 1; 
			}
		}
		else
		{
			if(oldX<endX)
			{
				while(angle==oldAngle)
				{
					angle=(short)(GetRandNumber(AngleMin,AngleMax))+ 1;
				}
			}
			else
			{
				while(angle==oldAngle)
				{
					angle=(short)(GetRandNumber(AngleMin,AngleMax))+90+45;
				}
			}
		}
		oldAngle=angle;
		angle*=.017453293;
		usePower=(short)(rand()%powerL)+1;
		powerL-=usePower;
		newX=usePower*cos(angle)+oldX;
		newY=usePower*sin(angle)+oldY;
		ColorCmb.R=GetRandNumber(lpColorLO->R,lpColorHI->R);
		ColorCmb.G=GetRandNumber(lpColorLO->G,lpColorHI->G);
		ColorCmb.B=GetRandNumber(lpColorLO->B,lpColorHI->B);
		WriteLine(oldX,oldY,newX,newY,lpImage,&ColorCmb);
		oldX=newX;
		oldY=newY;
		sX[i]=oldX;
		sY[i]=oldY;
		if(powerL<=0)break;
	}

	for(i=0;i<100;i++)
	{
		if(!sX[i]||!sY[i])break;
		oldX=sX[i];
		oldY=sY[i];
		powerL=subPower;
		for(i2=0;i2<100;i2++)
		{
			angle=(short)(rand()%360)+1;
			angle*=.017453293;
			usePower=(short)((rand()%powerL)+1);
			powerL=powerL-usePower;
			newX=usePower*cos(angle)+oldX;
			newY=usePower*sin(angle)+oldY;
			ColorCmb.R=GetRandNumber(lpColorLO->G,lpColorHI->R);
			ColorCmb.G=GetRandNumber(lpColorLO->G,lpColorHI->G);
			ColorCmb.B=GetRandNumber(lpColorLO->B,lpColorHI->B);
			WriteLine(oldX,oldY,newX,newY,lpImage,&ColorCmb);
			oldX=newX;
			oldY=newY;
			if(powerL<=0)break;
		}
	}
}
*/
unsigned long ScanLinearPathSegment(POINT *lpPointArray,POINT Beg,POINT End)
{
	long dx,dy,long_d,short_d,d,add_dh,add_dl,inc_xh,inc_yh,inc_xl,inc_yl,i;
	dx=End.x-Beg.x;
	dy=End.y-Beg.y;
	if(dx<0)
	{
		dx=-dx;
		inc_xh=-1;
		inc_xl=-1;
	}
	else	
	{
		inc_xh=1;
		inc_xl=1;
	}
	if(dy<0)
	{
		dy=-dy;
		inc_yh=-1;
		inc_yl=-1;
	}
	else
	{
		inc_yh=1;
		inc_yl=1;
	}
	if(dx>dy)
	{
		long_d=dx;
		short_d=dy;
		inc_yl=0;
	}
	else
	{
		long_d=dy;
		short_d=dx;
		inc_xl=0;
	}
	d=2*short_d-long_d;
	add_dl=2*short_d;
	add_dh=2*short_d-2*long_d;
	for(i=0;i<=long_d;i++)
	{
		lpPointArray[i].x=Beg.x;
		lpPointArray[i].y=Beg.y;
		if(d>=0)
		{
			Beg.x+=inc_xh;
			Beg.y+=inc_yh;
			d+=add_dh;
		}
		else
		{
			Beg.x+=inc_xl;
			Beg.y+=inc_yl;
			d+=add_dl;
		}
	}
	return long_d;
}
bool CheckVectorDirection(FC_Image *lpImage,POINT *lpOrigin,unsigned long RadialLength,unsigned char SectorIndex)
{
	short SweepFrom,SweepTo,Ang;
	switch(SectorIndex)
	{
	case SECTOR_S:
		SweepFrom=67;
		SweepTo=113;
		break;
	case SECTOR_SW:
		SweepFrom=112;
		SweepTo=158;
		break;
	case SECTOR_W:
		SweepFrom=157;
		SweepTo=203;
		break;
	case SECTOR_NW:
		SweepFrom=202;
		SweepTo=248;
		break;
	case SECTOR_N:
		SweepFrom=247;
		SweepTo=293;
		break;
	case SECTOR_NE:
		SweepFrom=292;
		SweepTo=338;
		break;
	case SECTOR_E:
		SweepFrom=337;
		SweepTo=383;
		break;
	case SECTOR_SE:
		SweepFrom=22;
		SweepTo=68;
		break;
	}
	for(Ang=SweepFrom;Ang<SweepTo;Ang++)if(GetPixel(lpImage->ImageDC,RadialLength*cos(Ang*(3.14/180))+lpOrigin->x,RadialLength*sin(Ang*(3.14/180))+lpOrigin->y)==0x0)return true;
	return false;
}
bool CheckVectorDirectionToActors(FC_Actor2D *lpActors,const char *lpExcludeName,unsigned long NumActors,POINT *lpOrigin,unsigned long RadialLength,unsigned char SectorIndex)
{
	unsigned long i;
	short SweepFrom,SweepTo,Ang;
	POINT	Point;
	RECT	Rect;
	switch(SectorIndex)
	{
	case SECTOR_S:
		SweepFrom=67;
		SweepTo=113;
		break;
	case SECTOR_SW:
		SweepFrom=112;
		SweepTo=158;
		break;
	case SECTOR_W:
		SweepFrom=157;
		SweepTo=203;
		break;
	case SECTOR_NW:
		SweepFrom=202;
		SweepTo=248;
		break;
	case SECTOR_N:
		SweepFrom=247;
		SweepTo=293;
		break;
	case SECTOR_NE:
		SweepFrom=292;
		SweepTo=338;
		break;
	case SECTOR_E:
		SweepFrom=337;
		SweepTo=383;
		break;
	case SECTOR_SE:
		SweepFrom=22;
		SweepTo=68;
		break;
	}
	for(i=0;i<NumActors;i++)
	{
		if(lpActors[i].Visible)
		{
			if(!EvalMsg(lpActors[i].Name,lpExcludeName))
			{
				for(Ang=SweepFrom;Ang<SweepTo;Ang++)
				{
					Rect.left=lpActors[i].zSortPoint.x-(lpActors[i].OutputWidth/4);
					Rect.right=lpActors[i].zSortPoint.x+(lpActors[i].OutputWidth/4);
					Rect.top=lpActors[i].zSortPoint.y-(lpActors[i].OutputHeight/4);
					Rect.bottom=lpActors[i].zSortPoint.y+(lpActors[i].OutputHeight/4);
					Point.x=RadialLength*cos(Ang*(3.14/180))+lpOrigin->x;
					Point.y=RadialLength*sin(Ang*(3.14/180))+lpOrigin->y;
					if(PtInRect(&Rect,Point))return true;
				}
			}
		}
	}
	return false;
}
signed char GetVectorDirection(POINT PointA,POINT PointB)
{
	signed long		Width;
	signed long		Height;
	long	angle;
	Width=(PointB.x-PointA.x);
	Height=(PointB.y-PointA.y);
	if(!Height)Height++;
	if(!Width)Width++;
	angle=abs(atan(Width/Height)*(180/3.14));
	if(angle>-23&&angle<23)
	{
		if(PointB.y>PointA.y)
		{
			return 0;
		}
		else
		{
			return 4;
		}
	}
	if(angle>67&&angle<157)
	{
		if(PointB.x>PointA.x)
		{
			return 6;
		}
		else
		{
			return 2;
		}
	}
	if(angle>22&&angle<68)
	{
		if(PointB.x<PointA.x)
		{
			if(PointB.y<PointA.y)
			{
				return 3;
			}
			else
			{
				return 1;
			}
		}
		else
		{
			if(PointB.y<PointA.y)
			{
				return 5;
			}
			else
			{
				return 7;
			}
		}
	}
	return -1;//Error
}
long SolveRelativeLong(long Ratio1Val,long Ratio1Max,long Ratio2Max,long OutputMin,long OutputMax)
{
	long TempLong;
	TempLong=(Ratio1Val*Ratio2Max)/Ratio1Max;
	if(TempLong<=OutputMin)return OutputMin;
	if(TempLong>=OutputMax)return OutputMax;
	return TempLong;
}
float SolveRelativeFloat(float Ratio1Val,float Ratio1Max,float Ratio2Max,float OutputMin,float OutputMax)
{
	float TempFloat;
	TempFloat=(Ratio1Val*Ratio2Max)/Ratio1Max;
	if(TempFloat<=OutputMin)return OutputMin;
	if(TempFloat>=OutputMax)return OutputMax;
	return TempFloat;
}
void ConvertRawToA3D(string File,float ScaleBy)
{
	
	FILE			*lpFile;
	char			*lpTempStr;
	signed long		*lpValues;
	char			TempStr[10];
	unsigned long	i=0,c=0;
	char			StrClip;
	unsigned long	b=0,ValueCount=0;
	unsigned long	VectorCount=0;
	unsigned long	MaxTo;
	//Open the RAW file and remove all the crlf characters and spaces
		lpTempStr=(char*)GlobalAlloc(GPTR,MAX_3D_FILE_LEN);
		lpValues=(signed long*)GlobalAlloc(GPTR,MAX_3D_TRIANGLES*9);
		lpFile=fopen(File.data(),"rb");
			fseek(lpFile,0,SEEK_SET);
			
			
			while(1)
			{
				if(!fread(&StrClip,1,1,lpFile))break;
				c++;//old file size
				if((StrClip!=0x0D)&&(StrClip!=0x0A)&&(StrClip!=0x20))
				{
					lpTempStr[b]=StrClip;
					b++;//new file size
				}
			}
		fclose(lpFile);
	//Take every 9 characters and put them into vectors
	VectorCount=0;
	MaxTo=b/9;
	for(i=0;i<MaxTo;i++)
	{
		memcpy(&TempStr[0],&lpTempStr[i*9],9);
		lpValues[i]=(atol(&TempStr[0])*ScaleBy);
		ValueCount++;
	}
	File.resize(File.size()-3);
	File=File+"A3D";
	lpFile=fopen(File.data(),"wb");
	fseek(lpFile,0,SEEK_SET);
	ValueCount/=9;
	fwrite(&ValueCount,sizeof(ValueCount),1,lpFile);
	ValueCount*=9;
	fwrite(&lpValues[0],sizeof(long)*ValueCount,1,lpFile);
	fclose(lpFile);
	GlobalFree(lpTempStr);
	GlobalFree(lpValues);
	return;
}
void Initiate3DE(void)
{
	unsigned short i;
	for(i=0;i<256;i++)
	{
		PreCalcSin[i]=sin(i/40.7436642);
		PreCalcCos[i]=cos(i/40.7436642);
	}
	EngineInitiated=true;
}
FS_Vector GetTriangleCenter(FS_Triangle *lpTri)
{
	FS_Vector TempVector;
	TempVector.x=(lpTri->Vector[0].x+lpTri->Vector[1].x+lpTri->Vector[2].x)/3;
	TempVector.y=(lpTri->Vector[0].y+lpTri->Vector[1].y+lpTri->Vector[2].y)/3;
	TempVector.z=(lpTri->Vector[0].z+lpTri->Vector[1].z+lpTri->Vector[2].z)/3;
	return TempVector;
}
FS_Vector GetTrianglesCenter(FS_Triangle *lpTri,unsigned long NumberOfTriangles)
{
	FS_Vector TempVector;
	unsigned long TriangleCounter,VectorCounter;
	long AddX=0,AddY=0,AddZ=0,VectorCount=0;		
	for(TriangleCounter=0;TriangleCounter<NumberOfTriangles;TriangleCounter++)
	{	
		for(VectorCounter=0;VectorCounter<3;VectorCounter++)
		{
			VectorCount++;
			AddX+=lpTri[TriangleCounter].Vector[VectorCounter].x;
			AddY+=lpTri[TriangleCounter].Vector[VectorCounter].y;
			AddZ+=lpTri[TriangleCounter].Vector[VectorCounter].z;
		}
	}
	TempVector.x=AddX/VectorCount;
	TempVector.y=AddY/VectorCount;
	TempVector.z=AddZ/VectorCount;
	return TempVector;
}
signed long GetTrianglesCenterX(FS_Triangle *lpTri,unsigned long NumberOfTriangles)
{
	unsigned long TriangleCounter,VectorCounter;
	long AddX=0,VectorCount=0;		
	for(TriangleCounter=0;TriangleCounter<NumberOfTriangles;TriangleCounter++)
	{	
		for(VectorCounter=0;VectorCounter<3;VectorCounter++)
		{
			VectorCount++;
			AddX+=lpTri[TriangleCounter].Vector[VectorCounter].x;
		}
	}
	return AddX/VectorCount;
}
signed long GetTrianglesCenterY(FS_Triangle *lpTri,unsigned long NumberOfTriangles)
{
	unsigned long TriangleCounter,VectorCounter;
	long AddY=0,VectorCount=0;		
	for(TriangleCounter=0;TriangleCounter<NumberOfTriangles;TriangleCounter++)
	{	
		for(VectorCounter=0;VectorCounter<3;VectorCounter++)
		{
			VectorCount++;
			AddY+=lpTri[TriangleCounter].Vector[VectorCounter].y;
		}
	}
	return AddY/VectorCount;
}
signed long GetTrianglesCenterZ(FS_Triangle *lpTri,unsigned long NumberOfTriangles)
{
	unsigned long TriangleCounter,VectorCounter;
	long AddZ=0,VectorCount=0;		
	for(TriangleCounter=0;TriangleCounter<NumberOfTriangles;TriangleCounter++)
	{	
		for(VectorCounter=0;VectorCounter<3;VectorCounter++)
		{
			VectorCount++;
			AddZ+=lpTri[TriangleCounter].Vector[VectorCounter].z;
		}
	}
	return AddZ/VectorCount;
}

signed long GetTrianglesLeft(FS_Triangle *lpTri,unsigned long NumberOfTriangles)
{
	unsigned long TriangleCounter,VectorCounter;
	long Temp=0,Value=LONG_MAX,VectorCount=0;		
	for(TriangleCounter=0;TriangleCounter<NumberOfTriangles;TriangleCounter++)
	{	
		for(VectorCounter=0;VectorCounter<3;VectorCounter++)
		{
			VectorCount++;
			Temp=lpTri[TriangleCounter].Vector[VectorCounter].x;
			if(Temp<Value)Value=Temp;
		}
	}
	return Value;
}
signed long GetTrianglesTop(FS_Triangle *lpTri,unsigned long NumberOfTriangles)
{
	unsigned long TriangleCounter,VectorCounter;
	long Temp=0,Value=LONG_MAX,VectorCount=0;		
	for(TriangleCounter=0;TriangleCounter<NumberOfTriangles;TriangleCounter++)
	{	
		for(VectorCounter=0;VectorCounter<3;VectorCounter++)
		{
			VectorCount++;
			Temp=lpTri[TriangleCounter].Vector[VectorCounter].y;
			if(Temp<Value)Value=Temp;
		}
	}
	return Value;
}
signed long GetTrianglesRight(FS_Triangle *lpTri,unsigned long NumberOfTriangles)
{
	unsigned long TriangleCounter,VectorCounter;
	long Temp=0,Value=0,VectorCount=0;		
	for(TriangleCounter=0;TriangleCounter<NumberOfTriangles;TriangleCounter++)
	{	
		for(VectorCounter=0;VectorCounter<3;VectorCounter++)
		{
			VectorCount++;
			Temp=lpTri[TriangleCounter].Vector[VectorCounter].x;
			if(Temp>Value)Value=Temp;
		}
	}
	return Value;
}
signed long GetTrianglesBottom(FS_Triangle *lpTri,unsigned long NumberOfTriangles)
{
	unsigned long TriangleCounter,VectorCounter;
	long Temp=0,Value=0,VectorCount=0;		
	for(TriangleCounter=0;TriangleCounter<NumberOfTriangles;TriangleCounter++)
	{	
		for(VectorCounter=0;VectorCounter<3;VectorCounter++)
		{
			VectorCount++;
			Temp=lpTri[TriangleCounter].Vector[VectorCounter].y;
			if(Temp>Value)Value=Temp;
		}
	}
	return Value;
}
FS_Vector GetActorCenter(FC_Actor3D *lpActor)
{
	FS_Vector TempVector;
	unsigned long TriangleCounter,VectorCounter;
	long AddX=0,AddY=0,AddZ=0,VectorCount=0;		
	for(TriangleCounter=0;TriangleCounter<lpActor->NumberOfTriangles;TriangleCounter++)
	{	
		for(VectorCounter=0;VectorCounter<3;VectorCounter++)
		{
			VectorCount++;
			AddX+=lpActor->lpTriangles[TriangleCounter].Vector[VectorCounter].x;
			AddY+=lpActor->lpTriangles[TriangleCounter].Vector[VectorCounter].y;
			AddZ+=lpActor->lpTriangles[TriangleCounter].Vector[VectorCounter].z;
		}
	}
	TempVector.x=AddX/VectorCount;
	TempVector.y=AddY/VectorCount;
	TempVector.z=AddZ/VectorCount;
	return TempVector;
}
//Low Level Transformation Functions
void ScaleTriangles(FS_Triangle *lpDest,FS_Triangle *lpSource,unsigned long NumTriangles,float ScaleX,float ScaleY,float ScaleZ,FS_Vector *lpOrigin)
{
	unsigned long i,b;
	for(i=0;i<NumTriangles;i++)
	{
		for(b=0;b<3;b++)
		{
			lpDest[i].Vector[b].x=lpSource[i].Vector[b].x-lpOrigin->x;
			lpDest[i].Vector[b].y=lpSource[i].Vector[b].y-lpOrigin->y;
			lpDest[i].Vector[b].z=lpSource[i].Vector[b].z-lpOrigin->z;
			(lpDest[i].Vector[b].x*=ScaleX)+=lpOrigin->x;
			(lpDest[i].Vector[b].y*=ScaleY)+=lpOrigin->y;
			(lpDest[i].Vector[b].z*=ScaleZ)+=lpOrigin->z;
		}
	}
	return;
}
void MoveTriangles(FS_Triangle *lpDest,FS_Triangle *lpSource,unsigned long NumTriangles,FS_Vector *lpMove,FS_Vector *lpOrigin)
{
	unsigned long i,b;
	signed long	DiffX,DiffY,DiffZ;
	for(i=0;i<NumTriangles;i++)
	{
		for(b=0;b<3;b++)
		{
			DiffX=lpSource[i].Vector[b].x-lpOrigin->x;
			DiffY=lpSource[i].Vector[b].y-lpOrigin->y;			
			DiffZ=lpSource[i].Vector[b].z-lpOrigin->z;
			lpDest[i].Vector[b].x=lpMove->x-DiffX;
			lpDest[i].Vector[b].y=lpMove->y-DiffY;
			lpDest[i].Vector[b].z=lpMove->z-DiffZ;
		}
	}
	return;
}
void RotateTriangles(FS_Triangle *lpDest,FS_Triangle *lpSource,unsigned long NumTriangles,FS_Vector *lpOrigin,FS_Vector *lpRotationVector)
{
	signed long i,b,xt,yt,zt;
	float cosalp,sinalp,cosbet,sinbet,cosgam,singam;
	cosalp=PreCalcCos[(unsigned char)lpRotationVector->x];
	sinalp=PreCalcSin[(unsigned char)lpRotationVector->x];
	cosbet=PreCalcCos[(unsigned char)lpRotationVector->y];
	sinbet=PreCalcSin[(unsigned char)lpRotationVector->y];
	cosgam=PreCalcCos[(unsigned char)lpRotationVector->z];
	singam=PreCalcSin[(unsigned char)lpRotationVector->z];
	PreCalcX1=cosalp*cosgam-sinalp*sinbet*singam;
	PreCalcY1=sinalp*cosgam+cosalp*sinbet*singam;
	PreCalcZ1=cosbet*singam;
	PreCalcX2=-sinalp*cosbet;
	PreCalcY2=cosalp*cosbet;
	PreCalcZ2=-sinbet;
	PreCalcX3=-cosalp*singam-sinalp*sinbet*cosgam;
	PreCalcY3=cosalp*sinbet*cosgam-sinalp*singam;
	PreCalcZ3=cosbet*cosgam;
	for(i=0;i<NumTriangles;i++)
	{
		for(b=0;b<3;b++)
		{
			xt=lpSource[i].Vector[b].x-lpOrigin->x;
			yt=lpSource[i].Vector[b].y-lpOrigin->y;
			zt=lpSource[i].Vector[b].z-lpOrigin->z;			
			lpDest[i].Vector[b].x=(signed long)(PreCalcX1*xt+PreCalcY1*yt+PreCalcZ1*zt)+lpOrigin->x;
			lpDest[i].Vector[b].y=(signed long)(PreCalcX2*xt+PreCalcY2*yt+PreCalcZ2*zt)+lpOrigin->y;
			lpDest[i].Vector[b].z=(signed long)(PreCalcX3*xt+PreCalcY3*yt+PreCalcZ3*zt)+lpOrigin->z;	
		}
	}	
}
FS_Vector MakeVector(long x,long y,long z)
{
	FS_Vector	TempVector={x,y,z};
	return TempVector;
}
signed long GetTriangleCenterZ(FS_Triangle *lpTriangle)
{
	return (lpTriangle->Vector[0].z+lpTriangle->Vector[1].z+lpTriangle->Vector[2].z)/3;
}
void SortTriangles(FS_Triangle Nodes[],long start,long count,bool asc)
{
	long L=start;
	long R=count;
	char flag=1;
	if(asc)flag=-1;
	if(R>L)
	{
		long i, j;
		FS_Triangle temp;
		i=L-1;
		j=R;
		for(;;)
		{
			long cmp;

			do
			{
				cmp=GetTriangleCenterZ(&Nodes[R])-GetTriangleCenterZ(&Nodes[++i]);
				cmp*=flag;
			}
			while (cmp<0);

			while (j>0)
			{
				long cmp2=GetTriangleCenterZ(&Nodes[R])-GetTriangleCenterZ(&Nodes[--j]);
				cmp2 *= flag;
				if(cmp2<=0)break;
			}
			if(i>=j)break;
			temp=Nodes[i];
			Nodes[i]=Nodes[j];
			Nodes[j]=temp;
		}
		temp=Nodes[i];
		Nodes[i]=Nodes[R];
		Nodes[R]=temp;
		SortTriangles(Nodes,L,i-1,asc);
		SortTriangles(Nodes,i+1,R,asc);
	}
	return;
}
//Internal Rasterization Function
void DrawTriangles(FC_Image *lpImage,FC_Image *lpTexture,FS_Color *lpColor,FS_Triangle *lpTri,unsigned long NumTriangles,unsigned char RenderMethod)
{
	POINT			s1[MAX_PATH_POINTS];
	POINT			s2[MAX_PATH_POINTS];
	POINT			s3[MAX_PATH_POINTS];
	unsigned long	lol1,lol2,lol3,b;
	POINT			Beg,End;
	FS_Triangle	*lpTrig;
	switch(RenderMethod)
	{
	case RENDERMODE_POINT:
		unsigned long i;
		for(i=0;i<NumTriangles;i++)
		{
			WritePixel(lpTri[i].Vector[0].x,lpTri[i].Vector[0].y,lpImage,lpColor);
			WritePixel(lpTri[i].Vector[1].x,lpTri[i].Vector[1].y,lpImage,lpColor);
			WritePixel(lpTri[i].Vector[2].x,lpTri[i].Vector[2].y,lpImage,lpColor);
		}
		return;
	case RENDERMODE_WIRE:
		for(i=0;i<NumTriangles;i++)
		{
			lpTrig=&lpTri[i];
			WriteLine(lpTrig->Vector[0].x,lpTrig->Vector[0].y,lpTrig->Vector[1].x,lpTrig->Vector[1].y,lpImage,lpColor);
			WriteLine(lpTrig->Vector[1].x,lpTrig->Vector[1].y,lpTrig->Vector[2].x,lpTrig->Vector[2].y,lpImage,lpColor);
			WriteLine(lpTrig->Vector[2].x,lpTrig->Vector[2].y,lpTrig->Vector[0].x,lpTrig->Vector[0].y,lpImage,lpColor);
		}
		return;
	case RENDERMODE_SOLID:
		for(b=0;b<NumTriangles;b++)
		{
			lpTrig=&lpTri[b];
			Beg.x=lpTrig->Vector[0].x;
			Beg.y=lpTrig->Vector[0].y;
			End.x=lpTrig->Vector[1].x;
			End.y=lpTrig->Vector[1].y;
			lol1=ScanLinearPathSegment(&s1[0],Beg,End);
			Beg.x=lpTrig->Vector[1].x;
			Beg.y=lpTrig->Vector[1].y;
			End.x=lpTrig->Vector[2].x;
			End.y=lpTrig->Vector[2].y;			
			lol2=ScanLinearPathSegment(&s2[0],Beg,End);
			Beg.x=lpTrig->Vector[2].x;
			Beg.y=lpTrig->Vector[2].y;
			End.x=lpTrig->Vector[0].x;
			End.y=lpTrig->Vector[0].y;
			lol3=ScanLinearPathSegment(&s3[0],Beg,End);
			for(i=0;i<lol1;i++)WriteLine(lpTrig->Vector[2].x,lpTrig->Vector[2].y,s1[i].x,s1[i].y,lpImage,lpColor);
			for(i=0;i<lol2;i++)WriteLine(lpTrig->Vector[0].x,lpTrig->Vector[0].y,s2[i].x,s2[i].y,lpImage,lpColor);
			for(i=0;i<lol3;i++)WriteLine(lpTrig->Vector[1].x,lpTrig->Vector[1].y,s3[i].x,s3[i].y,lpImage,lpColor);
		}
		return;
	case RENDERMODE_TEXTURE:
		for(b=0;b<NumTriangles;b++)
		{
			lpTrig=&lpTri[b];
			Beg.x=lpTrig->Vector[0].x;
			Beg.y=lpTrig->Vector[0].y;
			End.x=lpTrig->Vector[1].x;
			End.y=lpTrig->Vector[1].y;
			lol1=ScanLinearPathSegment(&s1[0],Beg,End);
			Beg.x=lpTrig->Vector[1].x;
			Beg.y=lpTrig->Vector[1].y;
			End.x=lpTrig->Vector[2].x;
			End.y=lpTrig->Vector[2].y;			
			lol2=ScanLinearPathSegment(&s2[0],Beg,End);
			Beg.x=lpTrig->Vector[2].x;
			Beg.y=lpTrig->Vector[2].y;
			End.x=lpTrig->Vector[0].x;
			End.y=lpTrig->Vector[0].y;
			lol3=ScanLinearPathSegment(&s3[0],Beg,End);
			for(i=0;i<lol1;i++)WriteTextureLine(lpTrig->Vector[2].x,lpTrig->Vector[2].y,s1[i].x,s1[i].y,lpImage,lpTexture);
			for(i=0;i<lol2;i++)WriteTextureLine(lpTrig->Vector[0].x,lpTrig->Vector[0].y,s2[i].x,s2[i].y,lpImage,lpTexture);
			for(i=0;i<lol3;i++)WriteTextureLine(lpTrig->Vector[1].x,lpTrig->Vector[1].y,s3[i].x,s3[i].y,lpImage,lpTexture);
		}
		return;
	}
	return;
}
/****************************
INTERANAL CALLBACK PROCEDURES
****************************/
void CALLBACK InternalProc1(HWAVEOUT hWaveOut,UINT Event,DWORD dwInstance,DWORD dwParam1,DWORD dwParam2)
{
	if(Event==WOM_DONE)
	{
		FC_Audio *lpAM=(FC_Audio*)dwInstance;
		if(lpAM)lpAM->Audio_Pulse();
	}
}
LRESULT CALLBACK InternalProc2(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	FC_ScrollBar *lpScrollBar=(FC_ScrollBar*)GetWindowLong(hWnd,GWL_USERDATA);
	switch(uMsg)
	{
	case WM_CREATE:
		return 0;
	case WM_ACTIVATE:
		if(wParam)
		{
			lpScrollBar->HasFocus=true;
		}
		else
		{
			lpScrollBar->HasFocus=false;			
		}
		InvalidateRect(hWnd,NULL,false);
		return 0;
	case WM_PAINT:
		char			Text[255];
		float			TempValue;
		RECT			TempRect;
		HDC				hDC;
		PAINTSTRUCT		PS;
		hDC=BeginPaint(hWnd,&PS);
		if(lpScrollBar->Vertical)
		{
			TempValue=(lpScrollBar->Value*(lpScrollBar->Rect.bottom-lpScrollBar->Rect.top))/lpScrollBar->Max;
			TempRect=MakeDeviceRect(2,TempValue-(lpScrollBar->Rect.right/2)+2,lpScrollBar->Rect.right-2,TempValue+(lpScrollBar->Rect.right/2)-2);
		}
		else
		{
			TempValue=(lpScrollBar->Value*(lpScrollBar->Rect.right-lpScrollBar->Rect.left))/lpScrollBar->Max;
			TempRect=MakeDeviceRect(TempValue-(lpScrollBar->Rect.bottom/2)+2,2,TempValue+(lpScrollBar->Rect.bottom/2)-2,lpScrollBar->Rect.bottom-2);
		}
		ltoa(lpScrollBar->Value,&Text[0],10);
		if(!lpScrollBar->OwnerDraw)
		{
			FillRect(lpScrollBar->Buffer.ImageDC,&lpScrollBar->Rect,(HBRUSH)GetStockObject(BLACK_BRUSH));		
			DrawText(lpScrollBar->Buffer.ImageDC,&Text[0],-1,&lpScrollBar->Rect,DT_CENTER|DT_VCENTER|DT_SINGLELINE);
			DrawEdge(lpScrollBar->Buffer.ImageDC,&TempRect,EDGE_RAISED,BF_RECT);		
			DrawEdge(lpScrollBar->Buffer.ImageDC,&lpScrollBar->Rect,EDGE_BUMP,BF_RECT);		
			if(lpScrollBar->HasFocus)DrawFocusRect(lpScrollBar->Buffer.ImageDC,&lpScrollBar->Rect);
		}
		else
		{	
			if(lpScrollBar->UseEvents)lpScrollBar->lpCallback(EVENT_SCROLLBAR_DRAW,OBJECT_SCROLLBAR,lpScrollBar,NULL,&TempValue,&Text[0]);
		}
		BitBlt(hDC,0,0,lpScrollBar->Rect.right,lpScrollBar->Rect.bottom,lpScrollBar->Buffer.ImageDC,0,0,SRCCOPY);
		EndPaint(hWnd,&PS);
		return 0;
	case WM_LBUTTONDOWN:
		if(PtInRect(&lpScrollBar->Rect,MakePoint(LOWORD(lParam),HIWORD(lParam))))
		{
			if(lpScrollBar->Vertical)
			{
				lpScrollBar->Value=SolveRelativeLong(HIWORD(lParam),lpScrollBar->Rect.bottom-lpScrollBar->Rect.top,lpScrollBar->Max+1,lpScrollBar->Min,lpScrollBar->Max);
			}
			else
			{
				lpScrollBar->Value=SolveRelativeLong(LOWORD(lParam),lpScrollBar->Rect.right-lpScrollBar->Rect.left,lpScrollBar->Max+1,lpScrollBar->Min,lpScrollBar->Max);
			}
			InvalidateRect(hWnd,NULL,false);
			return 0;
		}	
		return 0;
	case WM_MOUSEMOVE:
		if(wParam&MK_LBUTTON)
		{
			InternalProc2(hWnd,WM_LBUTTONDOWN,wParam,lParam);
		}
		return 0;
	case WM_DESTROY:
		return 0;
	default:
		return DefWindowProc(hWnd,uMsg,wParam,lParam);
	}
	return 0;
}